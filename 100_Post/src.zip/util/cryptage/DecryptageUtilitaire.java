package util.cryptage;

import static util.cryptage.CryptoConstante.LONGUEUR_KEY;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import util.convert.Convertisseur;

/**
 * Utilitaire en mode console permettant de connaitre le d�cryptage d'une chaine saisie au clavier.
 * @author totof
 */
public final class DecryptageUtilitaire {
    /**
     * Constructeur priv�.
     */
    private DecryptageUtilitaire() {
    }

    /**
     * @param args argument du main
     * @throws NoSuchPaddingException Exception du Crypter
     * @throws NoSuchAlgorithmException Exception du Crypter
     * @throws IllegalBlockSizeException Exception du Crypter
     * @throws BadPaddingException Exception du Crypter
     * @throws InvalidKeyException Exception du Crypter
     * @throws UnsupportedEncodingException Exception du Crypter
     */
    public static void main(final String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException {
        // Initialisation
        byte[] keyValue = new byte[LONGUEUR_KEY];
        keyValue = BigBourbaki.calcBigBourbaki(LONGUEUR_KEY).toString().substring(2).getBytes();
        Key key = new SecretKeySpec(keyValue, Crypter.getAlgorithm());

        // Saisie du mot de passe a crypter
        Scanner saisieUtilisateur = new Scanner(System.in);
        System.out.println("Veuillez saisir le mot de passe crypt� :");
        String input = saisieUtilisateur.nextLine();
        saisieUtilisateur.close();

        // D�cryptage
        byte[] encryptionBytes = Convertisseur.tabStringToTabByte(input);
        System.out.println("Mot de passe d�crypt�                     : " + Crypter.decrypt(encryptionBytes, key));
    }

}
