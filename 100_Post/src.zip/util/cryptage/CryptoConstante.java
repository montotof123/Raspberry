package util.cryptage;

/**
 * Constante pour le cryptage des donnees/mot de passe.
 * @author totof
 */
public final class CryptoConstante {
    /**
     * constructeur priv�.
     */
    private CryptoConstante() {
        throw new AssertionError();
    }

    /**
     * Longueur de la clef de cryptage.
     */
    public static final int LONGUEUR_KEY = 24;
    /**
     * Algorithme de cryptage.
     */
    public static final String ALGORITHME = "DESede";
}
