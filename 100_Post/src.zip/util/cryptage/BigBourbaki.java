package util.cryptage;

import static java.math.BigDecimal.ONE;
import static java.math.BigDecimal.ROUND_HALF_UP;

import java.math.BigDecimal;

/**
 * Calcul de PI tr�s pr�cis.
 * @author totof
 */
public final class BigBourbaki {
    /**
     * Constructeur priv�.
     */
    private BigBourbaki() {
    }

    /**
     * 2.
     */
    private static final BigDecimal TWO = new BigDecimal(2);
    /**
     * 4.
     */
    private static final BigDecimal FOUR = new BigDecimal(4);

    /**
     * 0.25.
     */
    private static final Double UN_QUART = 0.25;

    /**
     * Calcul PI avec une precision donnee (jusqu'a�quelques milliers de chiffres).
     * Algorithme Gauss-Legendre
     * @param scale nombre de chiffre apr�s la virgule
     * @return PI avec scale chiffre apres la virgule
     */
    public static BigDecimal calcBigBourbaki(final int scale) {
        BigDecimal a = ONE;
        BigDecimal b = ONE.divide(sqrt(TWO, scale), scale, ROUND_HALF_UP);
        BigDecimal t = new BigDecimal(UN_QUART);
        BigDecimal x = ONE;
        BigDecimal y;

        while (!a.equals(b)) {
            y = a;
            a = a.add(b).divide(TWO, scale, ROUND_HALF_UP);
            b = sqrt(b.multiply(y), scale);
            t = t.subtract(x.multiply(y.subtract(a).multiply(y.subtract(a))));
            x = x.multiply(TWO);
        }

        return a.add(b).multiply(a.add(b)).divide(t.multiply(FOUR), scale, ROUND_HALF_UP);
    }

    /**
     * Calcul de la racine carree tres precise (scale chiffre apres la virgule).
     * Babylonian square root method (Newton's method)
     * @param a le nombre dont on doit extraire la racine
     * @param scale nombre de chiffre apr_s la virgule
     * @return La racine carree
     */
    private static BigDecimal sqrt(final BigDecimal a, final int scale) {
        BigDecimal x0 = new BigDecimal("0");
        BigDecimal x1 = new BigDecimal(Math.sqrt(a.doubleValue()));

        while (!x0.equals(x1)) {
            x0 = x1;
            x1 = a.divide(x0, scale, ROUND_HALF_UP);
            x1 = x1.add(x0);
            x1 = x1.divide(TWO, scale, ROUND_HALF_UP);
        }

        return x1;
    }
}
