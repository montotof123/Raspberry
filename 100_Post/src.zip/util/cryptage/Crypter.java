package util.cryptage;

import static util.cryptage.CryptoConstante.ALGORITHME;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 * Cryptage des donn�es.
 * @author totof
 */
public final class Crypter {

    /**
     * Constructeur priv�.
     */
    private Crypter() {
    }

    /**
     * Permet le crytage et le decryptage de chaines de caracteres.
     */

    private static String algorithm = ALGORITHME;

    /**
     * Code une chaine de caractere.
     * @param input chaine � crypter
     * @param key clef de cryptage
     * @return La chaine codee
     */
    public static byte[] encrypt(final String input, final Key key) {
        Cipher cipher;
        byte[] result = null;
        try {
            cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] inputBytes = input.getBytes();
            result = cipher.doFinal(inputBytes);
        } catch (NoSuchAlgorithmException e) {
        	System.out.println(e.getMessage());
        } catch (NoSuchPaddingException e) {
        	System.out.println(e.getMessage());
        } catch (InvalidKeyException e) {
        	System.out.println(e.getMessage());
        } catch (IllegalBlockSizeException e) {
        	System.out.println(e.getMessage());
        } catch (BadPaddingException e) {
        	System.out.println(e.getMessage());
        }

        return result;
    }

    /**
     * D�code une chaine.
     * @param encryptionBytes chaine crypt�
     * @param key cl� de cryptage
     * @return La chaine decodee
     */
    public static String decrypt(final byte[] encryptionBytes, final Key key) {
        byte[] recoveredBytes = null;
        Cipher cipher;
        try {
            cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE, key);
            recoveredBytes = cipher.doFinal(encryptionBytes);
        } catch (NoSuchAlgorithmException e) {
        	System.out.println(e.getMessage());
        } catch (NoSuchPaddingException e) {
        	System.out.println(e.getMessage());
        } catch (InvalidKeyException e) {
        	System.out.println(e.getMessage());
        } catch (IllegalBlockSizeException e) {
        	System.out.println(e.getMessage());
        } catch (BadPaddingException e) {
        	System.out.println(e.getMessage());
        }

        return new String(recoveredBytes);
    }

    /**
     * Renvoie l'algorithme de codage utilise.
     * @return l'algorithme de codage
     */
    public static String getAlgorithm() {
        return algorithm;
    }
}
