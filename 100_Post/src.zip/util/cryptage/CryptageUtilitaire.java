package util.cryptage;

import static util.cryptage.CryptoConstante.LONGUEUR_KEY;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * Utilitaire en mode console permettant de connaitre le cryptage d'une chaine saisie au clavier.
 * @author totof
 */
public final class CryptageUtilitaire {
    /**
     * Constructeur priv�.
     */
    private CryptageUtilitaire() {
    }

    /**
     * @param args argument du main
     * @throws NoSuchPaddingException Exception du Crypter
     * @throws NoSuchAlgorithmException Exception du Crypter
     * @throws IllegalBlockSizeException Exception du Crypter
     * @throws BadPaddingException Exception du Crypter
     * @throws InvalidKeyException Exception du Crypter
     * @throws UnsupportedEncodingException Exception du Crypter
     */
    public static void main(final String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException {
        // Initialisation
        byte[] keyValue = new byte[LONGUEUR_KEY];
        keyValue = BigBourbaki.calcBigBourbaki(LONGUEUR_KEY).toString().substring(2).getBytes();
        Key key = new SecretKeySpec(keyValue, Crypter.getAlgorithm());

        // Saisie du mot de passe a crypter
        Scanner saisieUtilisateur = new Scanner(System.in);
        System.out.println("Veuillez saisir le mot de passe � crypter :");
        String input = saisieUtilisateur.nextLine();
        saisieUtilisateur.close();

        // Cryptage
        byte[] encryptionBytes = Crypter.encrypt(input, key);
        String cryptedS = new String(encryptionBytes, "8859_1");

        // Visualisation et controle
        System.out.println("Mot de passe saisie                       : " + input);
        System.out.println("Longueur du mot de passe crypt�           : " + encryptionBytes.length);
        System.out.print("Mot de passe crypt� en tableau d'octets   : ");
        for (int i = 0; i < encryptionBytes.length; i++) {
            System.out.print(encryptionBytes[i]);
            if (i != encryptionBytes.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();
        System.out.println("Mot de passe crypt� en string             : " + cryptedS);
        System.out.println("   Attention: difficilement utilisable");
        System.out.println("              � cause des caract�res");
        System.out.println("              sp�ciaux");
        System.out.println("Mot de passe d�crypt�                     : " + Crypter.decrypt(encryptionBytes, key));
    }

}
