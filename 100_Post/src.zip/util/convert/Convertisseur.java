package util.convert;

/**
 * Utilitaire de conversion de donn�es.
 * @author totof
 */
public final class Convertisseur {

    /**
     * Constructeur priv�.
     */
    private Convertisseur() {
    }

    /**
     * Conversion d'une string contenant une s�rie de nombre s�par�e par des virgules en tableau de byte.
     * @param tabString tableau d'octet stock� en string des fichiers properties
     * @return tableau d'octet
     */
    public static byte[] tabStringToTabByte(final String tabString) {

        String[] tabStringToConvert = tabString.split(",");

        byte[] tabByteConverted = new byte[tabStringToConvert.length];

        for (int i = 0; i < tabStringToConvert.length; i++) {
            tabByteConverted[i] = Byte.parseByte(tabStringToConvert[i].trim());
        }

        return tabByteConverted;
    }
}
