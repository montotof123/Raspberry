package postgreSql;

import static util.cryptage.CryptoConstante.LONGUEUR_KEY;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.Key;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import javax.crypto.spec.SecretKeySpec;

import util.convert.Convertisseur;
import util.cryptage.BigBourbaki;
import util.cryptage.Crypter;

/**
 * Lecture de la table composants du PostgreSql.
 * @author totof
 *
 */
public class SelectComposants2 {

	public static void main(String[] args) {
        // R�cup�ration de la cl� de cryptage
        byte[] keyValue = new byte[LONGUEUR_KEY];
        keyValue = BigBourbaki.calcBigBourbaki(LONGUEUR_KEY).toString().substring(2).getBytes();
        Key key = new SecretKeySpec(keyValue, Crypter.getAlgorithm());

        // Lecture du fichier properties
        Properties properties = new Properties();
		FileInputStream input = null;
		try {
			input = new FileInputStream(ClassLoader.getSystemResource("").getPath() + "/ressources/SelectComposants.properties");
			properties.load(input);
		} catch (IOException e1) {
			System.err.println(e1.getClass().getName() + ": " + e1.getMessage());
			System.exit(-1);
		}
		
		Connection c = null;
		Statement stmt = null;
		try {
			// Chargement du driver et connection
			byte[] encryptionBytes = Convertisseur.tabStringToTabByte(properties.getProperty("connection.password"));
			Class.forName(properties.getProperty("driver.name"));
			c = DriverManager.getConnection(properties.getProperty("connection.name") 
					+ "://" + properties.getProperty("connection.hostname") 
					+ ":" + properties.getProperty("connection.port") + "/" 
					+ properties.getProperty("connection.dbname"), 
					properties.getProperty("connection.login"), 
					Crypter.decrypt(encryptionBytes, key));
			c.setAutoCommit(false);
			System.out.println(properties.getProperty("connection.message.ok"));

			// Requ�te
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(properties.getProperty("requete.select")
					+ " " + properties.getProperty("table.champ.nom") + "," 
					+ " " + properties.getProperty("table.champ.utilisation") + "," 
					+ " " + properties.getProperty("table.champ.nbPatte") + "," 
					+ " " + properties.getProperty("table.champ.alimentation")
					+ " " + properties.getProperty("requete.from")
					+ " " + properties.getProperty("table.nom"));
			while (rs.next()) {
				// Lecture et affichage des donn�es
				String nom = rs.getString(properties.getProperty("table.champ.nom"));
				String utilisation = rs.getString(properties.getProperty("table.champ.utilisation"));
				int nbPatte = rs.getInt(properties.getProperty("table.champ.nbPatte"));
				float alimentation = rs.getFloat(properties.getProperty("table.champ.alimentation"));
				System.out.println(properties.getProperty("table.champ.nom.message") + nom);
				System.out.println(properties.getProperty("table.champ.utilisation.message") + utilisation);
				System.out.println(properties.getProperty("table.champ.nbPatte.message") + nbPatte);
				System.out.println(properties.getProperty("table.champ.alimentation.message") + alimentation);
				System.out.println();
			}
			
			// Fermeture de la connection et des traitements
			rs.close();
			stmt.close();
			c.close();
			
			input.close();
		} catch (Exception e) {
			// Erreur
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		// Message de succ�s
		System.out.println(properties.getProperty("message.fin"));
	}
}
