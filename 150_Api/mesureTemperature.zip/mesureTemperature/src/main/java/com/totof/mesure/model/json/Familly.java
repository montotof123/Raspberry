package com.totof.mesure.model.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Famille de device.
 * @author totof
 *
 */
public class Familly {
    private List<LstDevice> lstDevice;

    private LinksFamilly links;

    /**
     * Construteur avec parametres.
     * @param lstDevice la list des device
     * @param links le self lien
     */
    @JsonCreator
    public Familly(@JsonProperty("lstDevice")List<LstDevice> lstDevice, @JsonProperty("_links")LinksFamilly links) {
        super();
        this.lstDevice = lstDevice;
        this.links = links;
    }

    /**
     * Getter de la liste des devices.
     * @return la liste des devices
     */
    public List<LstDevice> getLstDevice() {
        return lstDevice;
    }

    /**
     * Setter de la liste des devices.
     * @param lstDevice la liste des devices
     */
    public void setLstDevice(List<LstDevice> lstDevice) {
        this.lstDevice = lstDevice;
    }

    /**
     * Getter du self lien.
     * @return le self lien
     */
    public LinksFamilly getLinks() {
        return links;
    }

    /**
     * Setter du self lien.
     * @param links le self lien
     */
    public void setLinks(LinksFamilly links) {
        this.links = links;
    }

    /**
     * Affichage.
     */
    @Override
    public String toString() {
        return "ClassPojo [lstDevice = " + lstDevice + ", _links = " + links + "]";
    }
}
    