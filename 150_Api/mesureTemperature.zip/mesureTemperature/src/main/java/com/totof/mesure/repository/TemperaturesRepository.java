package com.totof.mesure.repository;

import com.totof.mesure.model.jpa.Temperature;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository recuperant les fonctionnalites du JpaRepository Spring.
 * @author totof
 *
 */
@Repository
public interface TemperaturesRepository extends JpaRepository<Temperature, Long> {

}
