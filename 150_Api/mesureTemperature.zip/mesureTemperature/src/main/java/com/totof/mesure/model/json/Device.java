package com.totof.mesure.model.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Device.
 * @author totof
 *
 */
public class Device {
    /**
     * Fid.
     */
    private String fid;

    /**
     * crc.
     */
    private String crc;

    /**
     * id device.
     */
    private String idDevice;

    /**
     * Nom.
     */
    private String name;

    /**
     * Liens.
     */
    private LinksDevice links;

    /**
     * driver.
     */
    private String driver;

    /**
     * Temperature.
     */
    private float temperature;

    /**
     * Constructeur avec parametres.
     * @param fid le fid
     * @param crc le crc
     * @param idDevice l'id device
     * @param name le nom
     * @param links les liens
     * @param driver le driver
     * @param temperature la temperature
     */
    @JsonCreator
    public Device(@JsonProperty("fid") String fid, @JsonProperty("crc")String crc, 
            @JsonProperty("idDevice")String idDevice, 
            @JsonProperty("name")String name, @JsonProperty("_links")LinksDevice links, 
            @JsonProperty("driver")String driver, @JsonProperty("temperature") float temperature) {
        super();
        this.fid = fid;
        this.crc = crc;
        this.idDevice = idDevice;
        this.name = name;
        this.links = links;
        this.driver = driver;
        this.temperature = temperature;
    }

    /**
     * Getter fid.
     * @return le fid
     */
    public String getFid() {
        return fid;
    }

    /**
     * Setter fid.
     * @param fid le fid
     */
    public void setFid(String fid) {
        this.fid = fid;
    }

    /**
     * Getter crc.
     * @return le crc
     */
    public String getCrc() {
        return crc;
    }

    /**
     * Setter crc.
     * @param crc le crc
     */
    public void setCrc(String crc) {
        this.crc = crc;
    }

    /**
     * Getter de l'id device.
     * @return l'id device
     */
    public String getIdDevice() {
        return idDevice;
    }

    /**
     * Setter de l'id device.
     * @param idDevice l'id device
     */
    public void setIdDevice(String idDevice) {
        this.idDevice = idDevice;
    }

    /**
     * Getter du nom.
     * @return le nom
     */
    public String getName() {
        return name;
    }

    /**
     * Setter du nom.
     * @param name le nom
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter des liens.
     * @return les liens
     */
    public LinksDevice getLinks() {
        return links;
    }

    /**
     * Setter des liens.
     * @param links les liens
     */
    public void setLinks(LinksDevice links) {
        this.links = links;
    }

    /**
     * Getter du driver.
     * @return le driver
     */
    public String getDriver() {
        return driver;
    }

    /**
     * Setter du driver.
     * @param driver le driver
     */
    public void setDriver(String driver) {
        this.driver = driver;
    }

    /**
     * getter de la temperature.
     * @return la temperature
     */
    public float getTemperature() {
        return temperature;
    }

    /**
     * Setter de la temperature.
     * @param temperature la temperature
     */
    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    /**
     * Affichage.
     */
    @Override
    public String toString() {
        return "ClassPojo [fid = " + fid + ", crc = " 
                + crc + ", idDevice = " + idDevice + ", name = "
                + name + ", _links = " + links + ", driver = "
                + driver + ", temperature = " + temperature + "]";
    }
}
