package com.totof.mesure.model.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Les liens des devices.
 * @author totof
 *
 */
public class LinksDevice {
    /**
     * Le self lien.
     */
    private Link self;

    /**
     * Le lien vers la famille.
     */
    private Link familly;

    /**
     * Constructeur avec parametres.
     * @param self le self lien
     * @param familly le lien vers la famille
     */
    @JsonCreator
    public LinksDevice(@JsonProperty("self")Link self, @JsonProperty("Familly")Link familly) {
        super();
        this.self = self;
        this.familly = familly;
    }

    /**
     * Getter du self lien.
     * @return le self lien.
     */
    public Link getSelf() {
        return self;
    }

    /**
     * Setter du self lien.
     * @param self le self lien.
     */
    public void setSelf(Link self) {
        this.self = self;
    }

    /**
     * Getter du lien vers la famille.
     * @return le lien vers la famille
     */
    public Link getFamilly() {
        return familly;
    }

    /**
     * Setter du lien vers la famille.
     * @param familly le lien vers la famille
     */
    public void setFamilly(Link familly) {
        this.familly = familly;
    }

    /**
     * Affichage.
     */
    @Override
    public String toString() {
        return "ClassPojo [self = " + self + ", Familly = " + familly + "]";
    }
}
