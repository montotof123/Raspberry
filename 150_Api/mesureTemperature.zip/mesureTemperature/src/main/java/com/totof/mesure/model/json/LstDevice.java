package com.totof.mesure.model.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * La description des devices.
 * @author totof
 *
 */
public class LstDevice {
    /**
     * Le self lien.
     */
    private LinksFamilly links;

    /**
     * L'identifiant du device.
     */
    private String deviceId;

    /**
     * Constructeur avec parametres.
     * @param links le self lien
     * @param deviceId l'identifiant du device
     */
    @JsonCreator
    public LstDevice(@JsonProperty("_links")LinksFamilly links, @JsonProperty("deviceId")String deviceId) {
        super();
        this.links = links;
        this.deviceId = deviceId;
    }

    /**
     * Getter du le self lien.
     * @return le le self lien
     */
    public LinksFamilly get_links() {
        return links;
    }

    /**
     * Setter du self lien.
     * @param links le self lien
     */
    public void set_links(LinksFamilly links) {
        this.links = links;
    }

    /**
     * Getter de l'identifiant du device.
     * @return l'identifiant du device
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * Setter de l'identifiant du device.
     * @param deviceId l'identifiant du device
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * L'affichage.
     */
    @Override
    public String toString() {
        return "ClassPojo [_links = " + links + ", deviceId = " + deviceId + "]";
    }
}
    