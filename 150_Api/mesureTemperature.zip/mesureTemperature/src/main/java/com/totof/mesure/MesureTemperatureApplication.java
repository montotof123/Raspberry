package com.totof.mesure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Lanceur.
 * @author totof
 *
 */
@SpringBootApplication
@EnableScheduling
public class MesureTemperatureApplication {

    public static void main(String[] args) {
        SpringApplication.run(MesureTemperatureApplication.class, args);
    }
}
