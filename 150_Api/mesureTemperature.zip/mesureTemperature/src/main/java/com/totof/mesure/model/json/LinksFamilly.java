package com.totof.mesure.model.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Le lien des familles.
 * @author totof
 *
 */
public class LinksFamilly {
    /**
     * Le self lien.
     */
    private Link self;

    /**
     * Constructeur avec parametre.
     * @param self le self lien
     */
    @JsonCreator
    public LinksFamilly(@JsonProperty("self")Link self) {
        super();
        this.self = self;
    }

    /**
     * Getter du self lien.
     * @return le self lien
     */
    public Link getSelf() {
        return self;
    }

    /**
     * Setter du self lien.
     * @param self le self lien
     */
    public void setSelf(Link self) {
        this.self = self;
    }

    /**
     * Affichage.
     */
    @Override
    public String toString() {
        return "ClassPojo [self = " + self + "]";
    }
}
    