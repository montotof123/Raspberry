package com.totof.mesure;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totof.mesure.model.jpa.Temperature;
import com.totof.mesure.model.json.Device;
import com.totof.mesure.model.json.Familly;
import com.totof.mesure.model.json.LstDevice;
import com.totof.mesure.repository.TemperaturesRepository;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Fonction principale cyclique.
 * @author totof
 *
 */
@Component
public class ScheduledTasks {

    @Inject
    TemperaturesRepository temperaturesRepository;
    
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    
    private static final String DEVICE = "devices";
    
    private static final String DS18B20 = "28";
    
    private static final String BASE_URL = "http://192.168.1.27:8081/api/v1/onewire";
    
    private static final String START = "Start -> ";
    
    private static final String END = "End   -> ";

    /**
     * Sauvegarde de la temperature de toutes les sondes DS18B20 toutes les minutes.
     */
    @Scheduled(fixedRate = 60000)
    public void saveTemperature() {
        // Message de debut
        System.out.println(START + dateFormat.format(new Date()));
        // initialisation client http
        ClientConfig config = new ClientConfig();
        Client client = ClientBuilder.newClient(config);
        WebTarget target = client.target(UriBuilder.fromUri(BASE_URL).build());

        // Liste des devices de la famille 28 (DS18B20)
        String jsonFamilly = target.path(DEVICE).path(DS18B20).request().accept(MediaType.APPLICATION_JSON)
                 .get(String.class);
        ObjectMapper mapperFamilly = new ObjectMapper();
        Familly famille = null;
        try {
            famille = mapperFamilly.readValue(jsonFamilly, Familly.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Lecture des devices trouves
        for (LstDevice lstDevice : famille.getLstDevice()) {
            String jsonDevice = target.path(DEVICE).path(lstDevice.getDeviceId())
                    .request().accept(MediaType.APPLICATION_JSON).get(String.class);
            ObjectMapper mapperDevice = new ObjectMapper();
            Device device = null;
            try {
                device = mapperDevice.readValue(jsonDevice, Device.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            // Sauvegarde des temperatures dans la table
            temperaturesRepository.saveAndFlush(new Temperature(device.getName(), device.getTemperature()));
        }
        System.out.println(END + dateFormat.format(new Date()));
    }
}