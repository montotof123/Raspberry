package com.totof.mesure.model.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Mapping bdd.
 * @author totof
 *
 */
@Entity
@Table(name = "temperatures")
public class Temperature implements Serializable {
    /**
     * Generated serial.
     */
    private static final long serialVersionUID = 2065236940486663601L;

    /**
     * Id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private long id;
    
    /**
     * Horloge.
     */
    @Column(name = "horloge", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date horloge;
    
    /**
     * Nom du peripherique 1-wire.
     */
    @Column(name = "peripherique", nullable = false)
    private String peripherique;
    
    /**
     * Valeur de la temperature.
     */
    @Column(name = "valeur", nullable = false)
    private Float valeur;

    /**
     * Constructeur vide.
     */
    public Temperature() {
        super();
    }

    /**
     * Constructeur avec parametres.
     * les autres parametres sont generes
     * @param peripherique le peripherique
     * @param valeur la valeur
     */
    public Temperature(String peripherique, Float valeur) {
        super();
        this.horloge = new Date();
        this.peripherique = peripherique;
        this.valeur = valeur;
    }

    /**
     * Getter id.
     * @return l'id
     */
    public long getId() {
        return id;
    }

    /**
     * Setter id.
     * @param id l'id
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Getter horloge.
     * @return l'horloge
     */
    public Date getHorloge() {
        return horloge;
    }

    /**
     * Setter horloge.
     * @param horloge l'horloge
     */
    public void setHorloge(Date horloge) {
        this.horloge = horloge;
    }

    /**
     * Getter peripherique.
     * @return le peripherique
     */
    public String getPeripherique() {
        return peripherique;
    }

    /**
     * Setter peripherique.
     * @param peripherique le peripherique
     */
    public void setPeripherique(String peripherique) {
        this.peripherique = peripherique;
    }

    /**
     * getter valeur.
     * @return la valeur
     */
    public Float getValeur() {
        return valeur;
    }

    /**
     * Setter valeur.
     * @param valeur la valeur
     */
    public void setValeur(Float valeur) {
        this.valeur = valeur;
    }

    /**
     * Informations.
     */
    @Override
    public String toString() {
        return "Temperatures [id=" + id + ", horloge=" + horloge + ", peripherique=" + peripherique + ", valeur="
                + valeur + "]";
    }
}
