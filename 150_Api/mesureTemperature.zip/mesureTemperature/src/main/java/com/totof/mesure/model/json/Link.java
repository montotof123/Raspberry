package com.totof.mesure.model.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Lien.
 * @author totof
 *
 */
public class Link {
    private String href;

    /**
     * Constructeur avec parametre.
     * @param href l'url du lien
     */
    @JsonCreator
    public Link(@JsonProperty("href")String href) {
        super();
        this.href = href;
    }

    /**
     * Getter de l'url du lien.
     * @return l'url du lien
     */
    public String getHref() {
        return href;
    }

    /**
     * Setter de l'url du lien.
     * @param href l'url du lien
     */
    public void setHref(String href) {
        this.href = href;
    }

    /**
     * Affichage.
     */
    @Override
    public String toString() {
        return "ClassPojo [href = " + href + "]";
    }
}
    
