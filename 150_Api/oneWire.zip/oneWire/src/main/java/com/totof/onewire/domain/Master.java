package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.inject.Named;

import org.springframework.hateoas.ResourceSupport;

/**
 * Gestion du master.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class Master extends ResourceSupport {
    
    /**
     * Le nom.
     */
    private String name;
    
    /**
     * Nombre max d'esclave.
     */
    private String maxSlaveCount;
    
    /**
     * Timeout.
     */
    private String timeout;
    
    /**
     * Driver.
     */
    private String driver;
    
    /**
     * Pointeur.
     */
    private String pointer;

    /**
     * Getter du nom.
     * @return le nom
     */
    public String getName() {
        return name;
    }

    /**
     * Setter du nom.
     * @param name le nom
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter du nombre max de peripheriques.
     * @return le nombre max de peripherique
     */
    public String getMaxSlaveCount() {
        return maxSlaveCount;
    }

    /**
     * Setter du nombre max de peripheriques.
     * @param maxSlaveCount le nombre max de peripheriques
     */
    public void setMaxSlaveCount(String maxSlaveCount) {
        this.maxSlaveCount = maxSlaveCount;
    }

    /**
     * Getter du timeout.
     * @return le timeout
     */
    public String getTimeout() {
        return timeout;
    }

    /**
     * Setter du timeout.
     * @param timeout le timeout
     */
    public void setTimeout(String timeout) {
        this.timeout = timeout;
    }

    /**
     * Getter du driver.
     * @return le driver
     */
    public String getDriver() {
        return driver;
    }

    /**
     * Setter du driver.
     * @param driver le driver
     */
    public void setDriver(String driver) {
        this.driver = driver;
    }

    /**
     * Getter du pointeur.
     * @return le pointeur
     */
    public String getPointer() {
        return pointer;
    }

    /**
     * Setter du pointeur.
     * @param pointer le pointeur
     */
    public void setPointer(String pointer) {
        this.pointer = pointer;
    }
}
