package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.inject.Named;

/**
 * Gestion du peripherique DS18B20.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class DS18B20 extends Slave {
    
    /**
     * Controle de la mesure.
     */
    private String crc;
    
    /**
     * Temperature.
     */
    private String temperature;
    
    /**
     * Getter name.
     * use by Spring
     * @return name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Getter driver.
     * use by Spring
     * @return driver
     */
    public String getDriver() {
        return driver;
    }
    
    /**
     * Getter fid.
     * use by Spring
     * @return fid
     */
    public String getFid() {
        return fid;
    }
    
    /**
     * Getter id.
     * use by Spring
     * @return id
     */
    public String getIdDevice() {
        return idDevice;
    }
    
    /**
     * Getter du CRC.
     * @return le CRC
     */
    public String getCrc() {
        return crc;
    }

    /**
     * Setter du CRC.
     * @param crc le crc
     */
    public void setCrc(String crc) {
        this.crc = crc;
    }

    /**
     * Getter de la temperature.
     * @return temperature la temperature
     */
    public String getTemperature() {
        return temperature;
    }

    /**
     * Setter de la temperature.
     * @param temperature la temperature
     */
    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }
}
