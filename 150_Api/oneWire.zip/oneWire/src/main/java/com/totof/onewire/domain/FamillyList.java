package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;

import org.springframework.hateoas.ResourceSupport;

/**
 * Gestion des list de famille.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class FamillyList extends ResourceSupport {
    /**
     * list de famille.
     */
    List<Familly> lstFamilly = new ArrayList<Familly>();

    /**
     * Getter list de famille.
     * @return list de famille
     */
    public List<Familly> getLstFamilly() {
        return lstFamilly;
    }

    /**
     * Setter list de famille.
     * @param lstFamilly list de famille.
     */
    public void setLstFamilly(List<Familly> lstFamilly) {
        this.lstFamilly = lstFamilly;
    }
    
    /**
     * Familly.
     * @author totof
     *
     */
    public class Familly extends ResourceSupport {
        /**
         * Id de la famille.
         */
        private String famillyId;

        /**
         * Getter Id de la famille.
         * @return l'Id de la famille
         */
        public String getFamillyId() {
            return famillyId;
        }

        /**
         * Setter Id de la famille.
         * @param famillyId l'Id de la famille
         */
        public void setFamillyId(String famillyId) {
            this.famillyId = famillyId;
        }
    }
}
