package com.totof.onewire.utils;

import static com.totof.onewire.utils.ApplicationConstante.CHEMIN_DEFAUT;
import static com.totof.onewire.utils.ApplicationConstante.PORT;
import static com.totof.onewire.utils.ApplicationConstante.SLASH;

/**
 * Mise a disposition des constantes dans l'application.
 * @author totof
 *
 */
public final class ConstanteDispatcher {
    /**
     * Getter du chemin par defaut.
     * @return chemin par defaut
     */
    public static String getCheminDefaut() {
        return CHEMIN_DEFAUT;
    }
    
    /**
     * Getter du slash.
     * @return le slash
     */
    public static String getSlash() {
        return SLASH;
    }
    
    /**
     * Getter du port.
     * @return le port
     */
    public static int getPort() {
        return PORT;
    }
}
