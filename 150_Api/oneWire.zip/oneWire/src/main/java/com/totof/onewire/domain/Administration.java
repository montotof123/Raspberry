package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.inject.Named;

import org.springframework.hateoas.ResourceSupport;

/**
 * Gestion des parametres reseau.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class Administration extends ResourceSupport {

    /**
     * LocalHost HostAddress.
     */
    private String localHostHostAddress;

    /**
     * LocalHost HostName.
     */
    private String localHostHostName;

    /**
     * LoopBackAddress HostAddress.
     */
    private String loopBackAddressHostAddress;

    /**
     * LoopBackAddress HostName.
     */
    private String loopBackAddressHostName;

    /**
     * Port de l'application.
     */
    private int applicationPort;

    /**
     * Request ServerName.
     */
    private String requestServerName;

    /**
     * Request ServerPort.
     */
    private int requestServerPort;

    /**
     * Request LocalName.
     */
    private String requestLocalName;

    /**
     * Request LocalPort.
     */
    private int requestLocalPort;

    /**
     * Request RemoteAddress.
     */
    private String requestRemoteAddress;

    /**
     * Request RemotePort.
     */
    private int requestRemotePort;

    /**
     * Getter LocalHost HostAddress.
     * @return the LocalHost HostAddress
     */
    public String getLocalHostHostAddress() {
        return localHostHostAddress;
    }

    /**
     * Setter LocalHost HostAddress.
     * @param localHostHostAddress the LocalHost HostAddress
     */
    public void setLocalHostHostAddress(String localHostHostAddress) {
        this.localHostHostAddress = localHostHostAddress;
    }

    /**
     * Getter LocalHost HostName.
     * @return the LocalHost HostName
     */
    public String getLocalHostHostName() {
        return localHostHostName;
    }

    /**
     * Setter LocalHost HostName.
     * @param localHostHostName the LocalHost HostName
     */
    public void setLocalHostHostName(String localHostHostName) {
        this.localHostHostName = localHostHostName;
    }

    /**
     * Getter LoopBackAddress HostAddress.
     * @return the LoopBackAddress HostAddress
     */
    public String getLoopBackAddressHostAddress() {
        return loopBackAddressHostAddress;
    }

    /**
     * Setter LoopBackAddress HostAddress.
     * @param loopBackAddressHostAddress the LoopBackAddress HostAddress
     */
    public void setLoopBackAddressHostAddress(String loopBackAddressHostAddress) {
        this.loopBackAddressHostAddress = loopBackAddressHostAddress;
    }

    /**
     * Getter LoopBackAddress HostName.
     * @return the LoopBackAddress HostName
     */
    public String getLoopBackAddressHostName() {
        return loopBackAddressHostName;
    }

    /**
     * Setter LoopBackAddress HostName.
     * @param loopBackAddressHostName the LoopBackAddress HostName
     */
    public void setLoopBackAddressHostName(String loopBackAddressHostName) {
        this.loopBackAddressHostName = loopBackAddressHostName;
    }

    /**
     * Getter Port de l'application.
     * @return the Port de l'application
     */
    public int getApplicationPort() {
        return applicationPort;
    }

    /**
     * Setter Port de l'application.
     * @param applicationPort the Port de l'application
     */
    public void setApplicationPort(int applicationPort) {
        this.applicationPort = applicationPort;
    }

    /**
     * Getter Request ServerName.
     * @return the Request ServerName
     */
    public String getRequestServerName() {
        return requestServerName;
    }

    /**
     * Setter Request ServerName.
     * @param requestServerName the Request ServerName
     */
    public void setRequestServerName(String requestServerName) {
        this.requestServerName = requestServerName;
    }

    /**
     * Getter Request ServerPort.
     * @return the Request ServerPort
     */
    public int getRequestServerPort() {
        return requestServerPort;
    }

    /**
     * Setter Request ServerPort.
     * @param requestServerPort the Request ServerPort
     */
    public void setRequestServerPort(int requestServerPort) {
        this.requestServerPort = requestServerPort;
    }

    /**
     * Getter Request LocalName.
     * @return the Request LocalName
     */
    public String getRequestLocalName() {
        return requestLocalName;
    }

    /**
     * Setter Request LocalName.
     * @param requestLocalName the Request LocalName
     */
    public void setRequestLocalName(String requestLocalName) {
        this.requestLocalName = requestLocalName;
    }

    /**
     * Getter Request LocalPort.
     * @return the Request LocalPort
     */
    public int getRequestLocalPort() {
        return requestLocalPort;
    }

    /**
     * Setter Request LocalPort.
     * @param requestLocalPort the Request LocalPort
     */
    public void setRequestLocalPort(int requestLocalPort) {
        this.requestLocalPort = requestLocalPort;
    }

    /**
     * Getter Request RemoteAddress.
     * @return the Request RemoteAddress
     */
    public String getRequestRemoteAddress() {
        return requestRemoteAddress;
    }

    /**
     * Setter Request RemoteAddress.
     * @param requestRemoteAddress the Request RemoteAddress
     */
    public void setRequestRemoteAddress(String requestRemoteAddress) {
        this.requestRemoteAddress = requestRemoteAddress;
    }

    /**
     * Getter Request RemotePort.
     * @return the Request RemotePort
     */
    public int getRequestRemotePort() {
        return requestRemotePort;
    }

    /**
     * Setter Request RemotePort.
     * @param requestRemotePort the Request RemotePort
     */
    public void setRequestRemotePort(int requestRemotePort) {
        this.requestRemotePort = requestRemotePort;
    }
}
