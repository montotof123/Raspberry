package com.totof.onewire.domain;

/**
 * Constante de gestion du bus 1wire.
 * 
 * @author totof
 */
public final class MasterConstante {
    /**
     * Constructeur private.
     */
    private MasterConstante() {
    }

    /**
     * Liste des parametres master.
     */
    public enum MasterData {
        /**
         * Fichier du nom du master.
         */
        NameFile("w1_master_name"),
      
        /**
         * Fichier du nombre max de circuit.
         */
        MaxSlaveCountFile("w1_master_max_slave_count"),
        
        /**
         * Fichier du timeout.
         */
        TimeoutFile("w1_master_timeout"),
        
        /**
         * Fichier du driver.
         */
        DriverFile("uevent"),
        
        /**
         * Fichier du pointeur.
         */
        PointerFile("w1_master_pointer");
        /**
         * Le nom.
         */
        private String name = "";

        /**
         * Contructeur.
         * @param parmName Le nom
         */
        MasterData(final String parmName) {
            this.name = parmName;
        }

        /**
         * Conversion en String return le nom.
         */
        @Override
        public String toString() {
            return name;
        }
    }
}
