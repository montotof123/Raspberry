package com.totof.onewire.error;

import java.net.URL;

/**
 * Erruer.
 * @author totof
 *
 */
public class Error {

    /**
     * Code erreur.
     */
    private String code;

    /**
     * Message d'erreur.
     */
    private String message;

    /**
     * Description de l'erreur.
     */
    private String description;

    /**
     * URL d'info de l'erreur.
     */
    private URL infoUrl;

    /**
     * Constructeur.
     * @param code le code
     * @param message le message
     * @param description la description
     * @param infoUrl l'URL
     */
    public Error(ErrorCode code, String message, String description, URL infoUrl) {
        super();
        this.code = code.getValue();
        this.message = message;
        this.description = description;
        this.infoUrl = infoUrl;
    }

    /**
     * Constructeur vide.
     */
    public Error() {
    }

    /**
     * Getter code.
     * @return le code
     */
    public String getCode() {
        return code;
    }

    /**
     * Setter code.
     * @param code le code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Setter code.
     * @param code le code
     */
    public void setCode(ErrorCode code) {
        this.code = code.getValue();
    }

    /**
     * Getter message.
     * @return le message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Setter message.
     * @param message le message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Getter description.
     * @return la description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Setter description.
     * @param description la description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Getter de l'url d'info.
     * @return l'url d'info
     */
    public URL getInfoUrl() {
        return infoUrl;
    }

    /**
     * Setter de l'url d'info.
     * @param infoUrl l'url d'info
     */
    public void setInfoUrl(URL infoUrl) {
        this.infoUrl = infoUrl;
    }
}

