package com.totof.onewire.service;

import static com.totof.onewire.service.ServiceConstante.WRITE_DS2431_FAIL;
import static com.totof.onewire.service.ServiceConstante.WRITE_DS2431_SUCCESS;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.totof.onewire.api.MesureApi;
import com.totof.onewire.domain.ResultWriteDs2431;
import com.totof.onewire.domain.SlaveConstante.SlaveDS2431;
import com.totof.onewire.utils.ConstanteDispatcher;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.hateoas.Link;

/**
 * Service des slaves devices.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneWireDs2431ServiceImpl {

    @Inject
    ResultWriteDs2431 resultWriteDs2431;
    
    /**
     * Getter full message.
     * @param file le chemin du fichier
     * @return le full message
     * @throws IOException fichier not found
     */
    public String getFullMessage(File file) throws IOException {
        String fullMessage = new String(Files.readAllBytes(
                Paths.get(ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() + SlaveDS2431.MessageDS2431File.toString())));
        return fullMessage;
    }
    
    /**
     * Getter message.
     * @param file le chemin du fichier
     * @return le message
     * @throws IOException fichier not found
     */
    public String getMessage(File file) throws IOException {
        FileReader fileReader2d = new FileReader(
                ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() + SlaveDS2431.MessageDS2431File.toString());
        BufferedReader reader2d = new BufferedReader(fileReader2d);
        String message = reader2d.readLine();
        reader2d.close();
        fileReader2d.close();  
        return message;
    }
    
    /**
     * Ecriture du message dans l'eeprom du DS2431.
     * @param id id du device
     * @param message message a ecrire
     * @return message de confirmation
     * @throws IOException fichier not found
     */
    public ResultWriteDs2431 setMessage(String id, String message) throws IOException {
        // Nom du fichier pour ecriture dans l'eeprom
        String nomFichier = ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
            + id + ConstanteDispatcher.getSlash() + SlaveDS2431.MessageDS2431File.toString();
        
        // Ecriture du message
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(nomFichier), "utf-8"))) {
            writer.write(message + System.getProperty("line.separator"));
            writer.close();
        }
        
        // Relecture du message
        FileReader fileReader2d = new FileReader(nomFichier);
        BufferedReader reader2d = new BufferedReader(fileReader2d);
        String messageVerif = reader2d.readLine();
        reader2d.close();
        fileReader2d.close();
        
        if (message.equals(messageVerif)) {
            resultWriteDs2431.setResultat(WRITE_DS2431_SUCCESS);
        } else {
            resultWriteDs2431.setResultat(WRITE_DS2431_FAIL);
        }
        Link linkSelfDevice = linkTo(methodOn(MesureApi.class).setDs2431Message(id, message)).withSelfRel();
        resultWriteDs2431.add(linkSelfDevice);
        
        Link linkVerifDevice = linkTo(methodOn(MesureApi.class).getDevicesById(id)).withRel("DS2431");
        resultWriteDs2431.add(linkVerifDevice);
        
        return resultWriteDs2431;
    }
}
