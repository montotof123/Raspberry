package com.totof.onewire.service;

/**
 * Constante de gestion du bus 1wire.
 * 
 * @author totof
 */
public final class ServiceConstante {
    /**
     * Constructeur private.
     */
    private ServiceConstante() {
    }

    /**
     * Nom par defaut du master.
     */
    public static final String FID_MASTER = "w1";
    
    /**
     * Message succes d'ecriture dans l'eeprom DS2431.
     */
    public static final String WRITE_DS2431_SUCCESS = "Message écrit dans l'eeprom";

    /**
     * Message erreur d'ecriture dans l'eeprom DS2431.
     */
    public static final String WRITE_DS2431_FAIL = "Erreur d'écriture dans l'eeprom";
}
