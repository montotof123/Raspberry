package com.totof.onewire.utils;

/**
 * Constante de gestion du bus 1wire.
 * 
 * @author totof
 */
public final class ApplicationConstante {
    /**
     * Constructeur private.
     */
    private ApplicationConstante() {
    }

    /**
     * Chemin par defaut des informations 1wire.
     */
    public static final String CHEMIN_DEFAUT = "/sys/bus/w1/devices";
    
    /**
     * slash.
     */
    public static final String SLASH = "/";
    
    /**
     * server port.
     */
    public static final int PORT = 8081;
}
