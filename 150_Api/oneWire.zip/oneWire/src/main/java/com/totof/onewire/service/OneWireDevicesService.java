package com.totof.onewire.service;

import com.totof.onewire.domain.Administration;
import com.totof.onewire.domain.DevicesList;
import com.totof.onewire.domain.FamillyList;
import com.totof.onewire.domain.Master;
import com.totof.onewire.domain.ResultWriteDs2431;
import com.totof.onewire.domain.Slave;

import java.io.IOException;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;

public interface OneWireDevicesService {
    /**
     * Donne la liste des noms de device.
     * 
     * @return la liste des devices
     * @throws IOException chemin device not found
     */
    public FamillyList getFamilly() throws IOException;
    
    /**
     * Donne les informations sur le master.
     * 
     * @return les informations sur le master
     * @throws IOException chemin device not found
     */
    public Master getMasterDevice() throws IOException;
    
    /**
     * Donne la liste des noms de device ayant un FID donné.
     * @param fid la famille de device
     * @return la liste des devices ayant ce FID
     * @throws IOException chemin device not found
     */
    public DevicesList getDevicesByFid(String fid) throws IOException;
    
    /**
     * Donne les informations d'un device ayant un ID donné.
     * @param id l'id du device
     * @return les informations du device
     * @throws IOException chemin device not found
     */
    public Slave getDevicesById(String id) throws IOException;
    
    /**
     * Charge les informations reseau.
     * @param request la requete
     * @return les informations reseau
     * @throws UnknownHostException Erreur reseau
     */
    public Administration getAdministration(HttpServletRequest request) throws UnknownHostException;

    /**
     * Chargement du message da,s l'eeprom DS2431.
     * @param id id du device
     * @param message le message
     * @return Message a afficher
     * @throws IOException fichier not found
     */
    public ResultWriteDs2431 setDs2431Message(String id, String message) throws IOException;
}
