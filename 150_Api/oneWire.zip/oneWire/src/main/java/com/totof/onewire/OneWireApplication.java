package com.totof.onewire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneWireApplication {

    public static void main(String[] args) {
        SpringApplication.run(OneWireApplication.class, args);
    }
}
