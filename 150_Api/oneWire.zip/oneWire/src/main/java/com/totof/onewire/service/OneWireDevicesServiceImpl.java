package com.totof.onewire.service;

import static com.totof.onewire.service.ServiceConstante.FID_MASTER;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.totof.onewire.api.MesureApi;
import com.totof.onewire.domain.Administration;
import com.totof.onewire.domain.DS18B20;
import com.totof.onewire.domain.DS2431;
import com.totof.onewire.domain.DevicesList;
import com.totof.onewire.domain.FamillyList;
import com.totof.onewire.domain.Master;
import com.totof.onewire.domain.MasterConstante.MasterData;
import com.totof.onewire.domain.ResultWriteDs2431;
import com.totof.onewire.domain.Slave;
import com.totof.onewire.utils.ConstanteDispatcher;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.hateoas.Link;

@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneWireDevicesServiceImpl implements OneWireDevicesService {

    @Inject
    Master master;
    
    @Inject
    Administration administration;
    
    @Inject
    FamillyList famillyList;

    @Inject
    DevicesList devicesList;
    
    @Inject
    DS18B20 ds18b20;
    
    @Inject
    DS2431 ds2431;
    
    @Inject
    OneWireSlaveServiceImpl oneWireSlaveServiceImpl;

    @Inject
    OneWireDs18b20ServiceImpl oneWireDs18b20ServiceImpl;

    @Inject
    OneWireDs2431ServiceImpl oneWireDs2431ServiceImpl;

    /**
     * Donne la liste des familles de peripheriques.
     * 
     * @return FamillyList la liste des familles de peripheriques
     */
    @Override
    public FamillyList getFamilly() throws IOException {
        // Cherche toutes les familles en enlevant les doublons.
        HashSet<String> lstCodeFamilly = new HashSet<String>();
        File dir = new File(ConstanteDispatcher.getCheminDefaut());
        File[] filesList = dir.listFiles();
        for (File file : filesList) {
            lstCodeFamilly.add(file.getName().substring(0, 2));
        }

        // Vide la liste, sinon on ajoute a chaque demande
        famillyList.getLstFamilly().clear();
        famillyList.removeLinks();
        
        // Charge les familles
        for (String codeFamilly : lstCodeFamilly) {
            FamillyList.Familly familly = famillyList.new Familly();
            familly.setFamillyId(codeFamilly);
     
            // Liens
            if (codeFamilly.equals(ServiceConstante.FID_MASTER)) {
                Link linkSelfMaster;
                linkSelfMaster = linkTo(methodOn(MesureApi.class).getMasterDevice()).withSelfRel();
                familly.add(linkSelfMaster);               
            } else {
                Link linkSelfSlave = linkTo(methodOn(MesureApi.class).getDevicesByFid(codeFamilly)).withSelfRel();
                familly.add(linkSelfSlave);
            }
            famillyList.getLstFamilly().add(familly);
        }
        // Liens
        Link linkSelf = linkTo(methodOn(MesureApi.class).getFamilly()).withSelfRel();
        famillyList.add(linkSelf);
        return famillyList;
    }

    /**
     * Donne les informations sur le master.
     * 
     * @return les informations sur le master
     * @throws IOException chemin device not found
     */
    @Override
    public Master getMasterDevice() throws IOException {
        master.removeLinks();
        File dir = new File(ConstanteDispatcher.getCheminDefaut());
        File[] filesList = dir.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.toLowerCase().startsWith(FID_MASTER);
            }
        });
        String name = new String(Files
                .readAllBytes(Paths.get(ConstanteDispatcher.getCheminDefaut() 
                        + ConstanteDispatcher.getSlash() 
                        + filesList[0].getName() 
                        + ConstanteDispatcher.getSlash() 
                        + MasterData.NameFile.toString())));
        // Enleve le caractere de saut de ligne
        name = name.substring(0, name.length() - 1);
        master.setName(name);
        String maxSlaveCount = new String(Files.readAllBytes(
                Paths.get(ConstanteDispatcher.getCheminDefaut() 
                        + ConstanteDispatcher.getSlash() 
                        + filesList[0].getName() 
                        + ConstanteDispatcher.getSlash() 
                        + MasterData.MaxSlaveCountFile.toString())));
        // Enleve le caractere de saut de ligne
        maxSlaveCount = maxSlaveCount.substring(0, maxSlaveCount.length() - 1);
        master.setMaxSlaveCount(maxSlaveCount);
        String timeout = new String(Files.readAllBytes(
                Paths.get(ConstanteDispatcher.getCheminDefaut() 
                        + ConstanteDispatcher.getSlash() 
                        + filesList[0].getName() 
                        + ConstanteDispatcher.getSlash() 
                        + MasterData.TimeoutFile.toString())));
        // Enleve le caractere de saut de ligne
        timeout = timeout.substring(0, timeout.length() - 1);
        master.setTimeout(timeout);
        String driver = new String(Files.readAllBytes(
                Paths.get(ConstanteDispatcher.getCheminDefaut() 
                        + ConstanteDispatcher.getSlash() 
                        + filesList[0].getName() 
                        + ConstanteDispatcher.getSlash() 
                        + MasterData.DriverFile.toString())));
        // Enleve le caractere de saut de ligne et le DRIVER=
        driver = driver.substring(7, driver.length() - 1);
        master.setDriver(driver);
        String pointer = new String(Files.readAllBytes(
                Paths.get(ConstanteDispatcher.getCheminDefaut() 
                        + ConstanteDispatcher.getSlash() 
                        + filesList[0].getName() 
                        + ConstanteDispatcher.getSlash() 
                        + MasterData.PointerFile.toString())));    
        // Enleve le caractere de saut de ligne
        pointer = pointer.substring(0, pointer.length() - 1); 
        master.setPointer(pointer);
        
        // Liens
        Link linkSelf = linkTo(methodOn(MesureApi.class).getMasterDevice()).withSelfRel();
        master.add(linkSelf);
        Link linkAllDevices = linkTo(methodOn(MesureApi.class)
                .getFamilly()).withRel("allDevices");
        master.add(linkAllDevices);
        return master;
    }
    
    /**
     * Charge les informations reseau.
     * 
     * @return les informations reseau
     * @throws UnknownHostException Erreur reseau
     */
    @Override
    public Administration getAdministration(HttpServletRequest request) throws UnknownHostException {
        administration.removeLinks();
        administration.setLocalHostHostAddress(InetAddress.getLocalHost().getHostAddress());
        administration.setLocalHostHostName(InetAddress.getLocalHost().getHostName());

        administration.setLoopBackAddressHostAddress(InetAddress.getLoopbackAddress().getHostAddress());
        administration.setLoopBackAddressHostName(InetAddress.getLoopbackAddress().getHostName());
        
        administration.setApplicationPort(ConstanteDispatcher.getPort());
        
        administration.setRequestServerName(request.getServerName());
        administration.setRequestServerPort(request.getServerPort());
        administration.setRequestLocalName(request.getLocalName());
        administration.setRequestLocalPort(request.getLocalPort());
        administration.setRequestRemoteAddress(request.getRemoteAddr());
        administration.setRequestRemotePort(request.getRemotePort());

        // Liens
        Link linkSelf = linkTo(methodOn(MesureApi.class).getAdministration(request)).withSelfRel();
        administration.add(linkSelf);
        return administration;
    }


    /**
     * Donne la liste des noms de device ayant un FID donné.
     * @param fid the FID
     * @return la liste des devices ayant ce FID
     * @throws IOException chemin device not found
     */
    @Override
    public DevicesList getDevicesByFid(String fid) throws IOException {
        File dir = new File(ConstanteDispatcher.getCheminDefaut());
        File[] filesList = dir.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.toLowerCase().startsWith(fid);
            }
        });
        
        devicesList.getLstDevice().clear();
        devicesList.removeLinks();
        
        for (File file : filesList) {
            DevicesList.Device device = devicesList.new Device();
            device.setDeviceId(file.getName());
            Link linkSelfSlave = linkTo(methodOn(MesureApi.class).getDevicesById(file.getName())).withSelfRel();
            device.add(linkSelfSlave);
            devicesList.getLstDevice().add(device);
        }
        
        // Liens
        Link linkSelf = linkTo(methodOn(MesureApi.class).getDevicesByFid(fid)).withSelfRel();
        devicesList.add(linkSelf);
        return devicesList;
    }

    /**
     * Donne les informations sur un slave device.
     * @param id the ID
     * @return les informations sur un slave device
     * @throws IOException chemin device not found
     */
    @Override
    public Slave getDevicesById(String id) throws IOException {
        File dir = new File(ConstanteDispatcher.getCheminDefaut());
        File[] filesList = dir.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.toLowerCase().equals(id);
            }
        });
        return setDevicesById(id, filesList[0]);
    }
    
    /**
     * Lit les informations sur un slave device.
     * @param id the ID
     * @param file the file device
     * @return les informations sur un slave device
     * @throws IOException chemin device not found
     */
    private Slave setDevicesById(String id, File file) throws IOException {
        switch (id.toUpperCase().substring(0, 2)) {
            case "01": break; // 01h liste des familles oneWire https://fr.wikipedia.org/wiki/1-Wire
            case "02": break; // 02h
            case "04": break; // 04h
            case "05": break; // 05h
            case "06": break; // 06h
            case "08": break; // 08h
            case "09": break; // 09h
            case "0A": break; // 0Ah
            case "0B": break; // 0Bh
            case "0C": break; // 0Ch
            case "0F": break; // 0Fh
            case "10": break; // 10h
            case "12": break; // 12h
            case "14": break; // 14h
            case "18": break; // 18h
            case "1A": break; // 1Ah
            case "1C": break; // 1Ch
            case "1D": break; // 1Dh
            case "1F": break; // 1Fh
            case "21": break; // 21h
            case "22": break; // 22h
            case "23": break; // 23h
            case "24": break; // 24h
            case "26": break; // 26h
            case "27": break; // 27h
            case "28": 
                ds18b20.removeLinks();
                ds18b20.setName(oneWireSlaveServiceImpl.getName(file));
                ds18b20.setDriver(oneWireSlaveServiceImpl.getDriver(file));
                ds18b20.setFid(oneWireSlaveServiceImpl.getFid(file));
                ds18b20.setIdDevice(oneWireSlaveServiceImpl.getId(file));
                ds18b20.setCrc(oneWireDs18b20ServiceImpl.getCrc(file));
                ds18b20.setTemperature(oneWireDs18b20ServiceImpl.getTemperature(file));
                // Liens
                Link linkSelf28Device = linkTo(methodOn(MesureApi.class).getDevicesById(id)).withSelfRel();
                ds18b20.add(linkSelf28Device);
                Link linkSelf28Familly = linkTo(methodOn(MesureApi.class)
                        .getDevicesByFid(id.substring(0, 2))).withRel("Familly");
                ds18b20.add(linkSelf28Familly);
                return ds18b20; // 28h
            case "29": break; // 29h
            case "2C": break; // 2Ch
            case "2D": 
                ds2431.removeLinks();
                ds2431.setName(oneWireSlaveServiceImpl.getName(file));
                ds2431.setDriver(oneWireSlaveServiceImpl.getDriver(file));
                ds2431.setFid(oneWireSlaveServiceImpl.getFid(file));
                ds2431.setIdDevice(oneWireSlaveServiceImpl.getId(file));
                ds2431.setFullMessage(oneWireDs2431ServiceImpl.getFullMessage(file));
                ds2431.setMessage(oneWireDs2431ServiceImpl.getMessage(file));
                // Liens
                Link linkSelf2dDevice = linkTo(methodOn(MesureApi.class).getDevicesById(id)).withSelfRel();
                ds2431.add(linkSelf2dDevice);
                Link linkSelf2dFamilly = linkTo(methodOn(MesureApi.class)
                        .getDevicesByFid(id.substring(0, 2))).withRel("Familly");
                ds2431.add(linkSelf2dFamilly);
                return ds2431; // 2Dh
            case "30": break; // 30h
            case "33": break; // 33h
            case "37": break; // 37h
            case "3A": break; // 3Ah
            case "41": break; // 41h
            case "91": break; // 91h
            default: break;
        } 
 
        return null;
    }

    @Override
    /**
     * Chargement du message da,s l'eeprom DS2431.
     * @param id id du device
     * @param data le message
     * @return Message a afficher
     */
    public ResultWriteDs2431 setDs2431Message(String id, String message) throws IOException {
        return oneWireDs2431ServiceImpl.setMessage(id, message);
    }
}
