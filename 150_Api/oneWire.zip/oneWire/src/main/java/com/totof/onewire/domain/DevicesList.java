package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;

import org.springframework.hateoas.ResourceSupport;

/**
 * Gestion des list de devices.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class DevicesList extends ResourceSupport {
    /**
     * list de device.
     */
    List<Device> lstDevice = new ArrayList<Device>();

    /**
     * Getter list de device.
     * @return list de device
     */
    public List<Device> getLstDevice() {
        return lstDevice;
    }

    /**
     * Setter list de device.
     * @param lstDevice list de device.
     */
    public void setLstDevice(List<Device> lstDevice) {
        this.lstDevice = lstDevice;
    }
    
    /**
     * Device.
     * @author totof
     *
     */
    public class Device extends ResourceSupport {
        /**
         * Id du device.
         */
        private String deviceId;

        /**
         * Getter Id du device.
         * @return l'Id du device
         */
        public String getDeviceId() {
            return deviceId;
        }

        /**
         * Setter Id du device.
         * @param deviceId l'Id du device
         */
        public void setDeviceId(String deviceId) {
            this.deviceId = deviceId;
        }
    }
}
