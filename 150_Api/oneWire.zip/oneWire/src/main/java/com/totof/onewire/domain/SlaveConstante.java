package com.totof.onewire.domain;

/**
 * Constante de gestion du bus 1wire.
 * 
 * @author totof
 */
public final class SlaveConstante {
    /**
     * Constructeur private.
     */
    private SlaveConstante() {
    }

    /**
     * Chemin par defaut des informations 1wire.
     */
    public static final String POINT = ".";

    /**
     * Liste des parametres esclaves.
     */
    public enum SlaveData {
        /**
         * Fichier du nom du slave.
         */
        NameFile("name"),

        /**
         * Fichier du nom du uevent.
         */
        UeventFile("uevent");
        /**
         * Le nom.
         */
        private String name = "";

        /**
         * Contructeur.
         * 
         * @param parmName
         *            Le nom
         */
        SlaveData(final String parmName) {
            this.name = parmName;
        }

        /**
         * Conversion en String. return le nom
         */
        @Override
        public String toString() {
            return name;
        }
    }

    /**
     * Liste des parametres esclaves DS2431.
     */
    public enum SlaveDS2431 {
        /**
         * Fichier du nom message slave du DS2431.
         */
        MessageDS2431File("eeprom");
        /**
         * Le nom.
         */
        private String name = "";

        /**
         * Contructeur.
         * @param parmName Le nom
         */
        SlaveDS2431(final String parmName) {
            this.name = parmName;
        }

        /**
         * Conversion en String. return le nom
         */
        @Override
        public String toString() {
            return name;
        }
    }

    /**
     * Liste des parametres esclaves DS18B20.
     */
    public enum SlaveDS18B20 {
        /**
         * Fichier du nom du fichier du DS18B20.
         */
        DataDS18B20File("w1_slave");
        /**
         * Le nom.
         */
        private String name = "";

        /**
         * Contructeur.
         * @param parmName Le nom
         */
        SlaveDS18B20(final String parmName) {
            this.name = parmName;
        }

        /**
         * Conversion en String. return le nom
         */
        @Override
        public String toString() {
            return name;
        }
    }
}
