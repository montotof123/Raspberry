package com.totof.onewire.api;

import static com.totof.onewire.utils.LogConstante.METHODE;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

import com.totof.onewire.domain.Administration;
import com.totof.onewire.domain.DevicesList;
import com.totof.onewire.domain.FamillyList;
import com.totof.onewire.domain.Master;
import com.totof.onewire.domain.ResultWriteDs2431;
import com.totof.onewire.domain.Slave;
import com.totof.onewire.service.OneWireDevicesService;
import com.totof.onewire.utils.MethodHelper;

import java.io.IOException;
import java.net.UnknownHostException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.config.EnableHypermediaSupport;
import org.springframework.hateoas.config.EnableHypermediaSupport.HypermediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableHypermediaSupport(type = HypermediaType.HAL)
@RequestMapping(value = "/api/v1/onewire", produces = { APPLICATION_JSON_UTF8_VALUE })
@CrossOrigin

/**
 * API.
 * 
 * @author totof
 *
 */
public class MesureApi {
    /**
     * Logger.
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    /**
     * List des devices.
     */
    @Inject
    private OneWireDevicesService devicesServices;

    /**
     * Url d'informations sur les adresses et ports.
     * @param request la requete
     * @return les informations sur les adresses et ports
     * @throws UnknownHostException erreur reseau
     */
    @GetMapping("/admin")
    public Administration getAdministration(HttpServletRequest request) throws UnknownHostException {
        logger.debug(METHODE + MethodHelper.getCurrentMethodName(), request);
        return devicesServices.getAdministration(request);
    }

    /**
     * Donne la liste des familles de devices.
     * 
     * @return la liste des familles de devices
     * @throws IOException chemin device not found
     */
    @GetMapping("/familly")
    public FamillyList getFamilly() throws IOException {
        logger.debug(METHODE + MethodHelper.getCurrentMethodName());
        return devicesServices.getFamilly();
    }

    /**
     * Donne les informations sur le master.
     * 
     * @return les informations sur le master
     * @throws IOException chemin device not found
     */
    @GetMapping("/devices/master")
    public Master getMasterDevice() throws IOException {
        logger.debug(METHODE + MethodHelper.getCurrentMethodName());
        return devicesServices.getMasterDevice();
    }

    /**
     * Donne la liste des devices ayant un FID donné.
     * (2 caracteres)
     * @param fid la famille de device
     * @return la liste des devices ayant un FID donné
     * @throws IOException chemin device not found
     */
    @GetMapping("/devices/{fid:[a-zA-Z0-9]{2}}")
    public DevicesList getDevicesByFid(@PathVariable String fid) throws IOException {
        logger.debug(METHODE + MethodHelper.getCurrentMethodName(), fid);
        return devicesServices.getDevicesByFid(fid);
    }

    /**
     * Donne les informations sur un slave device.
     * (2 caracteres, 1 tiret, au moins 1 caractere)
     * @param id l'id du device
     * @return les informations sur un slave device
     * @throws IOException chemin device not found
     */
    @GetMapping("/devices/{id:[a-zA-Z0-9]{2}-[a-zA-Z0-9]{1,}}")
    public Slave getDevicesById(@PathVariable String id) throws IOException {
        logger.debug(METHODE + MethodHelper.getCurrentMethodName(), id);
        return devicesServices.getDevicesById(id);
    }
    
    /**
     * Ecrit un message dans l'eeprom d'un DS2431.
     * @param id l'id du DS2431
     * @param message le message a ecrire
     * @return message de confirmation
     * @throws IOException chemin device not found ou probleme de droit
     */
    @PostMapping("/devices/{id:2d-[a-zA-Z0-9]{1,}}")
    public ResultWriteDs2431 setDs2431Message(@PathVariable String id, 
            @RequestParam(value = "message", required = true) 
            String message) throws IOException {
        logger.debug(METHODE + MethodHelper.getCurrentMethodName(), id, message);
        return devicesServices.setDs2431Message(id, message);
    }
}
