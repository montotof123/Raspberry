package com.totof.onewire.utils;

/**
 * Liste des constantes utiles aux log.
 * @author totof
 */
public final class LogConstante {
    /**
     * Constructeur.
     */
    private LogConstante() {
    }

    /**
     * Message pour le nom des m�thodes.
     */
    public static final String METHODE = " **** Methode = ";

    /**
     * Message d'entr�e dans une m�thode.
     */
    public static final String DEBUT = "-DEBUT-";

    /**
     * Message de sortie d'une m�thode.
     */
    public static final String FIN = "--FIN--";
}
