package com.totof.onewire.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.totof.onewire.domain.SlaveConstante.SlaveDS18B20;
import com.totof.onewire.utils.ConstanteDispatcher;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.inject.Named;

/**
 * Service des slaves devices.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneWireDs18b20ServiceImpl {
    /**
     * Getter crc.
     * @param file le chemin du fichier
     * @return le crc
     * @throws IOException fichier not found
     */
    public String getCrc(File file) throws IOException {
        FileReader fileReader28 = new FileReader(
                ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() + SlaveDS18B20.DataDS18B20File.toString());
        BufferedReader reader28 = new BufferedReader(fileReader28);
        String crc = reader28.readLine().substring(36);
        reader28.close();
        fileReader28.close(); 
        return crc;
    }
    
    /**
     * Getter temperature.
     * @param file le chemin du fichier
     * @return la temperature
     * @throws IOException fichier not found
     */
    public String getTemperature(File file) throws IOException {
        FileReader fileReader28 = new FileReader(
                ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() + SlaveDS18B20.DataDS18B20File.toString());
        BufferedReader reader28 = new BufferedReader(fileReader28);
        String temperature = reader28.readLine();
        temperature = reader28.readLine().substring(29);
        float tempo = Float.parseFloat(temperature);
        temperature = Float.toString(tempo / 1000.0f);
        reader28.close();
        fileReader28.close();    
        return temperature;
    }
}
