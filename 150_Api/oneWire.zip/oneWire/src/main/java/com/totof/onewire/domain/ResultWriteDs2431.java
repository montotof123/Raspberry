package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.inject.Named;

import org.springframework.hateoas.ResourceSupport;

/**
 * Resultat ecriture DS2431.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultWriteDs2431 extends ResourceSupport {
    /**
     * Message resultat.
     */
    private String resultat;

    /**
     * Getter message resultat.
     * @return message resultat
     */
    public String getResultat() {
        return resultat;
    }

    /**
     * Setter message resultat.
     * @param resultat message resultat
     */
    public void setResultat(String resultat) {
        this.resultat = resultat;
    }
    
    

}
