package com.totof.onewire.domain;

import org.springframework.hateoas.ResourceSupport;

/**
 * Gestion des esclaves.
 * Classe abstraite de gestion des parametres commun des esclaves
 * @author totof
 *
 */
public abstract class Slave extends ResourceSupport {
    /**
     * Le nom.
     */
    protected String name;
    
    /**
     * Le driver.
     */
    protected String driver;
    
    /**
     * Le FID.
     */
    protected String fid;
    
    /**
     * l'ID.
     */
    protected String idDevice;

    /**
     * Getter du nom.
     * @return le nom
     */
    protected String getName() {
        return name;
    }

    /**
     * Setter du nom.
     * @param name le nom
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter du driver.
     * @return le driver
     */
    protected String getDriver() {
        return driver;
    }
    
    /**
     * Setter du driver.
     * @param driver le driver
     */
    public void setDriver(String driver) {
        this.driver = driver;
    }

    /**
     * Getter du FID.
     * @return le FID
     */
    protected String getFid() {
        return fid;
    }

    /**
     * Setter FID.
     * @param fid le fid
     */
    public void setFid(String fid) {
        this.fid = fid;
    }

    /**
     * Getter de l'ID.
     * @return l'ID
     */
    protected String getIdDevice() {
        return idDevice;
    }

    /**
     * Setter de l'ID.
     * @param idDevice l'ID
     */
    public void setIdDevice(String idDevice) {
        this.idDevice = idDevice;
    }
}
