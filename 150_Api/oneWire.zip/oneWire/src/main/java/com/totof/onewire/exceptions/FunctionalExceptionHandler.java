package com.totof.onewire.exceptions;

import com.totof.onewire.error.Error;
import com.totof.onewire.error.ErrorCode;

import java.io.IOException;
import java.net.UnknownHostException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice 
public class FunctionalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Constructeur.
     */
    public FunctionalExceptionHandler() {
    }

    /**
     * when trying to get a non existing resource.
     * @param e exception
     * @param request requete
     * @return error
     */
    @ExceptionHandler(value = { IllegalArgumentException.class })
    public final ResponseEntity<?> handleException(IllegalArgumentException e, WebRequest request) {
        HttpStatus status = HttpStatus.NOT_FOUND; 
        String labelCode = "Resource not exists.";
        Error error = new Error(ErrorCode.UNKNOWN_RESOURCE, labelCode, e.getMessage(), null);
        return new ResponseEntity<Error>(error, status); 
    }
    
    /**
     * Gestion IOException exception.
     * @param e exception
     * @param request requete
     * @return error
     */
    @ExceptionHandler(value = { IOException.class })
    public final ResponseEntity<?> handleIoException(Exception e, WebRequest request) {
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR; 
        String labelCode = "IOError.";
        Error error = new Error(ErrorCode.TECHNICAL_ERROR, labelCode, e.getMessage(), null);
        return new ResponseEntity<Error>(error, status); 
    } 
    
    /**
     * Gestion nullPointerException.
     * @param e exception
     * @param request requete
     * @return error
     */
    @ExceptionHandler(value = { NullPointerException.class })
    public final ResponseEntity<?> handleNullException(Exception e, WebRequest request) { 
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR; 
        String labelCode = "Pointeur null";
        Error error = 
                new Error(ErrorCode.TECHNICAL_ERROR, labelCode, e.getLocalizedMessage(), null);
        return new ResponseEntity<Error>(error, status); 
    }
    
    /**
     * Gestion UnknownHostException.
     * @param e exception
     * @param request requete
     * @return error
     */
    @ExceptionHandler(value = { UnknownHostException.class })
    public final ResponseEntity<?> handleHostException(Exception e, WebRequest request) { 
        HttpStatus status = HttpStatus.BAD_GATEWAY; 
        String labelCode = "Get Host error";
        Error error = 
                new Error(ErrorCode.TECHNICAL_ERROR, labelCode, e.getLocalizedMessage(), null);
        return new ResponseEntity<Error>(error, status); 
    }
}
