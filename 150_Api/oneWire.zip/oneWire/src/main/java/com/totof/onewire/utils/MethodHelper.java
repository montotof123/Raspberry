package com.totof.onewire.utils;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/**
 * Recuperation du nom des methodes pour les log.
 * @author totof
 */
public final class MethodHelper {
    /**
     * Constructeur.
     */
    private MethodHelper() {
    }

    /**
     * Return the full name of the routine that called getCurrentFullMethodName.
     * @author Johan, http://dev.kanngard.net
     * @return le nom et la classe de la methode d'appel.
     */

    public static String getCurrentFullMethodName() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(baos);
        (new Throwable()).printStackTrace(pw);
        pw.flush();
        String stackTrace = baos.toString();
        pw.close();

        StringTokenizer tok = new StringTokenizer(stackTrace, "\n");
        String l = tok.nextToken();
        l = tok.nextToken();
        l = tok.nextToken();
        tok = new StringTokenizer(l.trim(), " (");
        String t = tok.nextToken();
        t = tok.nextToken();

        return t;
    }

    /**
     * Return the name of the routine that called getCurrentMethodName.
     * @author Johan, http://dev.kanngard.net
     * @return le nom de la methode d'appel.
     */

    public static String getCurrentMethodName() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(baos);
        (new Throwable()).printStackTrace(pw);
        pw.flush();
        String stackTrace = baos.toString();
        pw.close();

        StringTokenizer tok = new StringTokenizer(stackTrace, "\n");
        String l = tok.nextToken();
        l = tok.nextToken();
        l = tok.nextToken();
        tok = new StringTokenizer(l.trim(), " (");
        String t = tok.nextToken();
        t = tok.nextToken();

        return t.substring(t.lastIndexOf('.') + 1);
    }

    /**
     * Return the package name of the routine that called getCurrentPackageName.
     * @author Johan, http://dev.kanngard.net
     * @return le nom de la methode d'appel.
     */

    public static String getCurrentPackageName() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(baos);
        (new Throwable()).printStackTrace(pw);
        pw.flush();
        String stackTrace = baos.toString();
        pw.close();

        StringTokenizer tok = new StringTokenizer(stackTrace, "\n");
        String l = tok.nextToken();
        l = tok.nextToken();
        l = tok.nextToken();
        tok = new StringTokenizer(l.trim(), " (");
        String t = tok.nextToken();
        t = tok.nextToken();

        return t.substring(0, t.substring(0, t.lastIndexOf('.')).lastIndexOf('.'));
    }

    /**
     * Return the class name of the routine that called getCurrentClassName.
     * @author Johan, http://dev.kanngard.net
     * @return le nom de la  methode d'appel.
     */

    public static String getCurrentClassName() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(baos);
        (new Throwable()).printStackTrace(pw);
        pw.flush();
        String stackTrace = baos.toString();
        pw.close();

        StringTokenizer tok = new StringTokenizer(stackTrace, "\n");
        String l = tok.nextToken();
        l = tok.nextToken();
        l = tok.nextToken();
        tok = new StringTokenizer(l.trim(), " (");
        String t = tok.nextToken();
        t = tok.nextToken();

        return t.substring(t.substring(0, t.lastIndexOf('.')).lastIndexOf('.') + 1, t.lastIndexOf('.'));
    }
}
