package com.totof.onewire.error;

/**
 * Code erreur.
 * @author totof
 *
 */
public enum ErrorCode {

    INVALID_QUERY("40001"),

    DUPLICATED_RESOURCE("40002"),

    UNKNOWN_RESOURCE("40401"),

    TECHNICAL_ERROR("50001"); 

    private String value;

    private ErrorCode(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}