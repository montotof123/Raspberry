package com.totof.onewire.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.inject.Named;

/**
 * Gestion du peripherique DS2431.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class DS2431 extends Slave {
    
    /**
     * Le message complet.
     */
    private String fullMessage;
    
    /**
     * Le message.
     */
    private String message;
    
    /**
     * Getter name.
     * use by Spring
     * @return name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Getter driver.
     * use by Spring
     * @return driver
     */
    public String getDriver() {
        return driver;
    }
    
    /**
     * Getter fid.
     * use by Spring
     * @return fid
     */
    public String getFid() {
        return fid;
    }
    
    /**
     * Getter id.
     * use by Spring
     * @return id
     */
    public String getIdDevice() {
        return idDevice;
    }
    
    /**
     * Getter du message complet.
     * @return le message complet
     */
    public String getFullMessage() {
        return fullMessage;
    }

    /**
     * Setter du message complet.
     * @param fullMessage le message complet
     */
    public void setFullMessage(String fullMessage) {
        this.fullMessage = fullMessage;
    }

    /**
     * Getter du message.
     * @return le message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Setter du message.
     * @param message le message
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
