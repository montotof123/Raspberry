package com.totof.onewire.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.totof.onewire.domain.SlaveConstante.SlaveData;
import com.totof.onewire.utils.ConstanteDispatcher;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.inject.Named;

/**
 * Service des slaves devices.
 * @author totof
 *
 */
@Named
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneWireSlaveServiceImpl {
    /**
     * Getter name.
     * @param file le chemin du fichier
     * @return le nom
     * @throws IOException fichier not found
     */
    public String getName(File file) throws IOException {
        String name = new String(Files
                .readAllBytes(Paths.get(ConstanteDispatcher.getCheminDefaut() 
                        + ConstanteDispatcher.getSlash() 
                        + file.getName() + ConstanteDispatcher.getSlash() 
                        + SlaveData.NameFile.toString())));
        // Enleve le caractere de saut de ligne
        name = name.substring(0, name.length() - 1);
        return name;
    }
    
    /**
     * Getter driver.
     * @param file le chemin du fichier
     * @return le driver
     * @throws IOException fichier not found
     */
    public String getDriver(File file) throws IOException {
        FileReader fileReader = new FileReader(
                ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() 
                + SlaveData.UeventFile.toString());
        BufferedReader reader = new BufferedReader(fileReader);
        String driver = reader.readLine();
        // Enleve le DRIVER=
        driver = driver.substring(7, driver.length());
        reader.close();
        fileReader.close();
        return driver;
    }
   
    /**
     * Getter fid.
     * @param file le chemin du fichier
     * @return le fid
     * @throws IOException fichier not found
     */
    public String getFid(File file) throws IOException {
        FileReader fileReader = new FileReader(
                ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() 
                + SlaveData.UeventFile.toString());
        BufferedReader reader = new BufferedReader(fileReader);
        String fid = reader.readLine();
        fid = reader.readLine();
        // Enleve le W1_FID=
        fid = fid.substring(7, fid.length());
        reader.close();
        fileReader.close();  
        return fid;
    }
    
    /**
     * Getter id.
     * @param file le chemin du fichier
     * @return l'id
     * @throws IOException fichier not found
     */
    public String getId(File file) throws IOException {
        FileReader fileReader = new FileReader(
                ConstanteDispatcher.getCheminDefaut() + ConstanteDispatcher.getSlash() 
                + file.getName() + ConstanteDispatcher.getSlash() 
                + SlaveData.UeventFile.toString());
        BufferedReader reader = new BufferedReader(fileReader);
        String id = reader.readLine();
        id = reader.readLine();
        id = reader.readLine();
        // Enleve le DRIVER=
        id = id.substring(12, id.length());
        reader.close();
        fileReader.close(); 
        return id;
    }
}
