package com.totof.onewire;

import static io.restassured.RestAssured.given;
import static io.restassured.parsing.Parser.JSON;

import io.restassured.RestAssured;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ServeurTest {
    
    private final String contentTypeJson = "application/json; charset=utf-8";
    private final int http200 = HttpStatus.OK.value();
    private final int http404 = HttpStatus.NOT_FOUND.value();
    private final int http500 = HttpStatus.INTERNAL_SERVER_ERROR.value();
    
    @LocalServerPort
    private int port;
    
    /**
     * Initialisation serveur test.
     * @throws Exception erreur serveur
     */
    @Before
    public void setUp() throws Exception {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = port;
        RestAssured.basePath = "/api/v1/onewire";
        RestAssured.defaultParser = JSON;
        RestAssured.requestSpecification = given().contentType(contentTypeJson);
    }
    
    @Test
    public void checkUriNotFound() throws Exception {
        given().when().get("/fake").then().statusCode(http404);
    }
    
    @Test
    public void checkUriAdministration() throws Exception {
        given(). when().get("/admin").then().statusCode(http200);
    }
    
    @Test
    public void checkUriFamilly() throws Exception {
        given().when().get("/familly").then().statusCode(http500);
    }
    
    @Test
    public void checkUriDeviceMaster() throws Exception {
        given().when().get("/devices/master").then().statusCode(http500);
    }
    
    @Test
    public void checkUriDeviceFamilly() throws Exception {
        given().when().get("/devices/28").then().statusCode(http500);
    }
}
