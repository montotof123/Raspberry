package test;

import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		Runtime runtime = Runtime.getRuntime();
		String[] argsRuntime = {"/usr/bin/sudo", "/home/pi/Projet/C-Cpp/robot/avance", "800"};
		try {
			final Process process = runtime.exec(argsRuntime);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
