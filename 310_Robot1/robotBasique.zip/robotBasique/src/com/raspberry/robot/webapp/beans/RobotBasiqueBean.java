package com.raspberry.robot.webapp.beans;

import java.io.IOException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.event.SlideEndEvent;

@ManagedBean(name = "robotBasiqueBean")
@SessionScoped
public class RobotBasiqueBean {
	// ****************
	// Constantes
	// ****************
	/**
	 * Francais.
	 */
	public static final String FRANCAIS = "fr";

	// ****************
	// Variable
	// ****************
	/**
	 * Langue.
	 */
	private String locale;
	
	/**
	 * Direction.
	 */
	private int direction;
	
	/**
	 * Acc�l�ration.
	 */
	private int vitesse;

	// ****************
	// Getter et Setter
	// ****************
	/**
	 * Getter de la langue.
	 * 
	 * @return la langue
	 */
	public final String getLocale() {
		return locale;
	}

	/**
	 * Setter de la langue.
	 * 
	 * @param pLocale la langue
	 */
	public final void setLocale(final String pLocale) {
		this.locale = pLocale;
	}

	/**
	 * Getter direction.
	 * @return direction la direction
	 */
	public int getDirection() {
		return direction;
	}

	/**
	 * Setter direction.
	 * @param pDirection la direction
	 */
	public void setDirection(int pDirection) {
		this.direction = pDirection;
	}

	/**
	 * Getter vitesse.
	 * @return direction la direction
	 */
	public int getVitesse() {
		return vitesse;
	}

	/**
	 * Setter vitesse.
	 * @param pVitesse la vitesse
	 */
	public void setVitesse(int pVitesse) {
		this.vitesse = pVitesse;
	}

	/**
	 * Gestion evenement fin de mouvement slider direction.
	 * @param pEvent l'evenement
	 */
	public void onDirectionEnd(SlideEndEvent pEvent) {
		// Rotation servo
		Runtime runtime = Runtime.getRuntime();
		String[] args = new String[6];
		args[0] = "/usr/bin/sudo";
		args[1] = "/home/pi/Projet/C-Cpp/robot/SERVO";			
		args[2] = "24";			
		args[3] = "121";			
		args[4] = "170";			
		args[5] = String.valueOf(pEvent.getValue());
		try {
			runtime.exec(args);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Tableau de commande des GPIO.
	 * @param GPIO numero du GPIO
	 * @param commande Commande a appliquer
	 * @return le tableau des commandes
	 */
	private String[] tabGPIO(String GPIO, String commande) {
		String[] args = new String[4];
		args[0] = "/usr/bin/sudo";
		args[1] = "/home/pi/Projet/C-Cpp/robot/GPIO";			
		args[2] = GPIO;			
		args[3] = commande;			
		return args;
	}
	
	/**
	 * Gestion evenement fin de mouvement slider vitesse.
	 * @param pEvent l'evenement
	 */
	public void onVitesseEnd(SlideEndEvent pEvent) {
		// Positionnement du PWM
		Runtime runtime = Runtime.getRuntime();
		String[] argsPot = new String[6];
		argsPot[0] = "/usr/bin/sudo";
		argsPot[1] = "/home/pi/Projet/C-Cpp/robot/AD5220";			
		argsPot[2] = "GPIO04";			
		argsPot[3] = "GPIO17";			
		argsPot[4] = "83000";			
		argsPot[5] = String.valueOf(Math.abs(pEvent.getValue()));			
		try {
			runtime.exec(argsPot);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// Arr�t
		try {
			runtime.exec(tabGPIO("GPIO05", "OFF"));
			runtime.exec(tabGPIO("GPIO06", "OFF"));
			runtime.exec(tabGPIO("GPIO16", "OFF"));
			runtime.exec(tabGPIO("GPIO20", "ON"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(pEvent.getValue() > 10000) {
			try {
			// Avant
				runtime.exec(tabGPIO("GPIO05", "ON"));
				runtime.exec(tabGPIO("GPIO06", "OFF"));
				// PWM actif
				runtime.exec(tabGPIO("GPIO16", "OFF"));
				runtime.exec(tabGPIO("GPIO20", "OFF"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(pEvent.getValue() < -10000) {
			try {
			// Arriere
				runtime.exec(tabGPIO("GPIO05", "OFF"));
				runtime.exec(tabGPIO("GPIO06", "ON"));
				// PWM actif
				runtime.exec(tabGPIO("GPIO16", "OFF"));
				runtime.exec(tabGPIO("GPIO20", "OFF"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		if(pEvent.getValue() == 83000) {
			try {
			// Avant
				runtime.exec(tabGPIO("GPIO05", "ON"));
				runtime.exec(tabGPIO("GPIO06", "OFF"));
				// A font
				runtime.exec(tabGPIO("GPIO16", "ON"));
				runtime.exec(tabGPIO("GPIO20", "OFF"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(pEvent.getValue() == -83000) {
			try {
			// Arriere
				runtime.exec(tabGPIO("GPIO05", "OFF"));
				runtime.exec(tabGPIO("GPIO06", "ON"));
				// A font
				runtime.exec(tabGPIO("GPIO16", "ON"));
				runtime.exec(tabGPIO("GPIO20", "OFF"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Constructeur.
	 */
	public RobotBasiqueBean() {
		// Initialisation de la langue
		locale = FRANCAIS;

	}
}
