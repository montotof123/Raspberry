package com.raspberry.oscilloscope.webapp.beans;

import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.ABSCISSE;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.ORDONNEE;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.NOMBRE_VALEUR_INITIALE;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.POINT_VIRGULE;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.CHARSET_ISO_8859_P1;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.ERREUR_LECTURE_FICHIER;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.io.IOUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.ItemSelectEvent;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.ChartSeries;
import org.primefaces.model.chart.LineChartModel;

import com.raspberry.oscilloscope.type.Point;
import com.raspberry.oscilloscope.webapp.beans.BeanConstante.Graphique;


@ManagedBean(name = "oscilloscopeBean")
@SessionScoped
public class OscilloscopeBean {
	// ****************
	// Constantes
	// ****************
	/**
	 * Francais.
	 */
	public static final String FRANCAIS = "fr";

	// ****************
	// Variable
	// ****************
	/**
	 * Langue.
	 */
	private String locale;

	/**
	 * La valeur min du fichier.
	 */
	private double valeurMinFichier = Double.POSITIVE_INFINITY;

	/**
	 * La valeur max du fichier.
	 */
	private double valeurMaxFichier = Double.NEGATIVE_INFINITY;

	/**
	 * La valeur min affiche.
	 */
	private double valeurMinAffiche = Double.POSITIVE_INFINITY;

	/**
	 * La valeur max affiche.
	 */
	private double valeurMaxAffiche = Double.NEGATIVE_INFINITY;

	/**
	 * Le nombre de valeurs du fichier.
	 */
	private int nombreValeurFichier;
	/**
	 * Le nombre de valeurs affiche.
	 */
	private int nombreValeurAffiche;

	/**
	 * Temps max du fichier.
	 */
	private int tempsMaxFichier = Integer.MAX_VALUE;
	
	/**
	 * Temps min du fichier.
	 */
	private int tempsMinFichier = Integer.MIN_VALUE;
	
	/**
	 * Temps max affiche.
	 */
	private int tempsMaxAffiche = Integer.MAX_VALUE;
	
	/**
	 * Temps mini affiche.
	 */
	private int tempsMinAffiche = Integer.MIN_VALUE;
	
	/**
	 * Graphique des mesures.
	 */
	private LineChartModel mesures;

	/**
	 * Serie de mesure.
	 */
	private ChartSeries mesuresSerie;

	/**
	 * Lignes du fichier de mesure.
	 */
	private List<String> lignes = null;

	/**
	 * Nom du fichier selectionne.
	 */
	private String nomFichier;
	
	/**
	 * Le point d'ordonnee minimum.
	 */
	private Point pointMin;
	
	/**
	 * Le point d'ordonnee maximum.
	 */
	private Point pointMax;
	
	/**
	 * La frequence.
	 */
	private double frequence = Double.NEGATIVE_INFINITY;

	/**
	 * La periode.
	 */
	private double periode = Double.NEGATIVE_INFINITY;
	
	/**
	 * Nombre de points entre le d�but du fichier et le d�but d'affichage.
	 */
	int deltaGraph;

	// ****************
	// Getter et Setter
	// ****************
	/**
	 * Getter de la langue.
	 * 
	 * @return la langue
	 */
	public final String getLocale() {
		return locale;
	}

	/**
	 * Setter de la langue.
	 * 
	 * @param pLocale la langue
	 */
	public final void setLocale(final String pLocale) {
		this.locale = pLocale;
	}

	/**
	 * Getter de la valeur min du fichier.
	 * 
	 * @return La valeur min du fichier
	 */
	public double getValeurMinFichier() {
		return valeurMinFichier;
	}

	/**
	 * Setter de la valeur min du fichier.
	 * 
	 * @param pValeurMinFichier La valeur min du fichier
	 */
	public void setValeurMinFichier(double pValeurMinFichier) {
		this.valeurMinFichier = pValeurMinFichier;
	}

	/**
	 * Getter de la valeur max du fichier.
	 * 
	 * @return La valeur max du fichier
	 */
	public double getValeurMaxFichier() {
		return valeurMaxFichier;
	}

	/**
	 * Setter de la valeur max du fichier.
	 * 
	 * @param pValeurMax La valeur max du fichier
	 */
	public void setValeurMaxFichier(double pValeurMax) {
		this.valeurMaxFichier = pValeurMax;
	}

	/**
	 * Getter du nombre de valeurs affiche.
	 * 
	 * @return Le nombre de valeurs affiche
	 */
	public int getNombreValeurAffiche() {
		return nombreValeurAffiche;
	}

	/**
	 * Setter du nombre de valeurs affiche.
	 * 
	 * @param pNombreValeurAffiche Le nombre de valeurs affiche
	 */
	public void setNombreValeurAffiche(int pNombreValeurAffiche) {
		this.nombreValeurAffiche = pNombreValeurAffiche;
	}

	/**
	 * Getter de la valeur min affiche.
	 * 
	 * @return La valeur min affiche
	 */
	public double getValeurMinAffiche() {
		return valeurMinAffiche;
	}

	/**
	 * Setter de la valeur min affiche.
	 * 
	 * @param valeurMax La valeur min affiche
	 */
	public void setValeurMinAffiche(double pValeurMinAffiche) {
		this.valeurMinAffiche = pValeurMinAffiche;
	}

	/**
	 * Getter de la valeur max affiche.
	 * 
	 * @return La valeur max affiche
	 */
	public double getValeurMaxAffiche() {
		return valeurMaxAffiche;
	}

	/**
	 * Setter de la valeur max affiche.
	 * 
	 * @param valeurMax La valeur max affiche
	 */
	public void setValeurMaxAffiche(double pValeurMaxAffiche) {
		this.valeurMaxAffiche = pValeurMaxAffiche;
	}

	/**
	 * Getter du nombre de valeur du fichier.
	 * 
	 * @return Le nombre de valeur du fichier
	 */
	public int getNombreValeurFichier() {
		return nombreValeurFichier;
	}

	/**
	 * Setter du nombre de valeur du fichier.
	 * 
	 * @param le nombre de valeur du fichier
	 */
	public void setNombreValeurFichier(int pNombreValeurFichier) {
		this.nombreValeurFichier = pNombreValeurFichier;
	}

	/**
	 * Getter du graphe de mesures.
	 * 
	 * @return Le graphe de mesures
	 */
	public LineChartModel getMesures() {
		return mesures;
	}

	/**
	 * Setter du graphe de mesures.
	 * 
	 * @param pMesures Le graphe de mesures
	 */
	public void setMesures(LineChartModel pMesures) {
		this.mesures = pMesures;
	}

	/**
	 * Getter du nom du fichiers.
	 * 
	 * @return Le nom du fichier
	 */
	public String getNomFichier() {
		return nomFichier;
	}

	/**
	 * Setter du nom du fichiers.
	 * 
	 * @param pNomFichier Le nom du fichier
	 */
	public void setNomFichier(String pNomFichier) {
		this.nomFichier = pNomFichier;
	}

	/**
	 * Getter du temps max du fichier.
	 * 
	 * @return Le temps max du fichier
	 */
	public int getTempsMaxFichier() {
		return tempsMaxFichier;
	}

	/**
	 * Setter du temps max du fichier.
	 * 
	 * @param pTempsMaxFichier Le temps max du fichier
	 */
	public void setTempsMaxFichier(int pTempsMaxFichier) {
		this.tempsMaxFichier = pTempsMaxFichier;
	}

	/**
	 * Getter du temps min du fichier.
	 * 
	 * @return Le temps min du fichier
	 */
	public int getTempsMinFichier() {
		return tempsMinFichier;
	}

	/**
	 * Setter du temps min du fichier.
	 * 
	 * @param pTempsMinFichier Le temps min du fichier
	 */
	public void setTempsMinFichier(int pTempsMinFichier) {
		this.tempsMinFichier = pTempsMinFichier;
	}

	/**
	 * Getter du temps max affiche.
	 * 
	 * @return Le temps max affiche
	 */
	public int getTempsMaxAffiche() {
		return tempsMaxAffiche;
	}

	/**
	 * Setter du temps min affiche.
	 * 
	 * @param pTempsMaxAffiche Le temps min affiche
	 */
	public void setTempsMaxAffiche(int pTempsMaxAffiche) {
		this.tempsMaxAffiche = pTempsMaxAffiche;
	}

	/**
	 * Getter du temps min affiche.
	 * 
	 * @return Le temps min affiche
	 */
	public int getTempsMinAffiche() {
		return tempsMinAffiche;
	}

	/**
	 * Setter du temps min affiche.
	 * 
	 * @param pTempsMinAffiche Le temps min affiche
	 */
	public void setTempsMinAffiche(int pTempsMinAffiche) {
		this.tempsMinAffiche = pTempsMinAffiche;
	}

	/**
	 * Getter du point min pour calcul de la frequence.
	 * 
	 * @return Le point min pour calcul de la frequence
	 */
	public Point getPointMin() {
		return pointMin;
	}

	/**
	 * Setter du point min pour calcul de la frequence.
	 * 
	 * @param pPointMin Le point min pour calcul de la frequence
	 */
	public void setPointMin(Point pPointMin) {
		this.pointMin = pPointMin;
	}

	/**
	 * Getter du point max pour calcul de la frequence.
	 * 
	 * @return Le point max pour calcul de la frequence
	 */
	public Point getPointMax() {
		return pointMax;
	}

	/**
	 * Setter du point max pour calcul de la frequence.
	 * 
	 * @param pPointMax Le point max pour calcul de la frequence
	 */
	public void setPointMax(Point pPointMax) {
		this.pointMax = pPointMax;
	}

	/**
	 * Getter de la frequence.
	 * 
	 * @return La frequence
	 */
	public double getFrequence() {
		return frequence;
	}

	/**
	 * Setter de la frequence.
	 * 
	 * @param pFrequence La frequence
	 */
	public void setFrequence(double pFrequence) {
		this.frequence = pFrequence;
	}

	/**
	 * Getter de la periode.
	 * 
	 * @return La periode
	 */
	public double getPeriode() {
		return periode;
	}

	/**
	 * Setter de la periode.
	 * 
	 * @param pPeriode La periode
	 */
	public void setPeriode(double pPeriode) {
		this.periode = pPeriode;
	}

	/**
	 * Chargement du fichier.
	 * 
	 * @param pEvent l'evenement
	 */
	public final void handleFileUpload(final FileUploadEvent pEvent) {
		// Nom du fichier charge
		nomFichier = pEvent.getFile().getFileName();
		
		// Lecture du fichier
		try {
			lignes = IOUtils.readLines(pEvent.getFile().getInputstream(), CHARSET_ISO_8859_P1);
			// Enleve la premiere ligne contenant les entetes
			lignes.remove(0);
		} catch (IOException e1) {
			// Message d'erreur
	    	FacesContext context = FacesContext.getCurrentInstance();
	    	context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, e1.getLocalizedMessage(),  ERREUR_LECTURE_FICHIER));
		}
		// Reinit valeurs
		valeurMinFichier = Double.POSITIVE_INFINITY;
		valeurMaxFichier = Double.NEGATIVE_INFINITY;
		valeurMinAffiche = Double.POSITIVE_INFINITY;
		valeurMaxAffiche = Double.NEGATIVE_INFINITY;
		tempsMinFichier = Integer.MAX_VALUE;
		tempsMaxFichier = Integer.MIN_VALUE;
		deltaGraph = 0;
		
		// Calcul de l'abscisse min
		String[] valeurMin = lignes.get(0).split(POINT_VIRGULE);
		tempsMinFichier = Integer.parseInt(valeurMin[ABSCISSE]);
		// Calcul de l'abscisse max
		String[] valeurMax = lignes.get(lignes.size() - 1).split(POINT_VIRGULE);
		tempsMaxFichier = Integer.parseInt(valeurMax[ABSCISSE]);

		// Affichage initial des nn premieres valeurs du fichier
		// ou du fichier entier si il n'y a pas nn valeurs
		tempsMinAffiche = tempsMinFichier;
		if (lignes.size() >= NOMBRE_VALEUR_INITIALE) {
			String[] valeurMinAffiche = lignes.get(NOMBRE_VALEUR_INITIALE - 1).split(POINT_VIRGULE);
			tempsMaxAffiche = Integer.parseInt(valeurMinAffiche[ABSCISSE]);
		} else {
			tempsMaxAffiche = tempsMaxFichier;
		}
		
		// Initialisation du graphique
		InitGraph();

		// Chargement des mesures de la fenetre d'affichage
		nombreValeurAffiche = 0;
		nombreValeurFichier = 0;
		for (String ligne : lignes) {
			String[] valeurs = ligne.split(POINT_VIRGULE);
			int x = Integer.parseInt(valeurs[ABSCISSE]);
			double y = Double.parseDouble(valeurs[ORDONNEE]);
			if(tempsMinAffiche <= x && tempsMaxAffiche > x){
				mesuresSerie.set(x, y);
				nombreValeurAffiche++;
				// Calcul de la valeur min a afficher
				if (y < valeurMinAffiche) {
					valeurMinAffiche = y;
				}
				// Calcul de la valeur max a afficher
				if (y > valeurMaxAffiche) {
					valeurMaxAffiche = y;
				}
			}
			// Calcul de la valeur min du fichier
			if (y < valeurMinFichier) {
				valeurMinFichier = y;
			}
			// Calcul de la valeur max du fichier
			if (y > valeurMaxFichier) {
				valeurMaxFichier = y;
			}
			// Nombre de valeur du fichier
			nombreValeurFichier++;
		}

		// Dessine le graphique
		DrawGraph();
	}

	/**
	 * Lancement des mesures.
	 */
	public void launchMesure() {

		// Reinit valeurs
		valeurMinAffiche = Double.POSITIVE_INFINITY;
		valeurMaxAffiche = Double.NEGATIVE_INFINITY;
		
		// Initialisation du graphique
		InitGraph();

		// Chargement des mesures de la fenetre d'affichage
		nombreValeurAffiche = 0;
		deltaGraph = 0;
		boolean debut = true;
		for (String ligne : lignes) {
			String[] valeurs = ligne.split(POINT_VIRGULE);
			int x = Integer.parseInt(valeurs[ABSCISSE]);
			double y = Double.parseDouble(valeurs[ORDONNEE]);
			if(tempsMinAffiche <= x && tempsMaxAffiche > x){
				debut = false;
				mesuresSerie.set(x, y);
				nombreValeurAffiche++;
				// Calcul de la valeur min a afficher
				if (y < valeurMinAffiche) {
					valeurMinAffiche = y;
				}
				// Calcul de la valeur max a afficher
				if (y > valeurMaxAffiche) {
					valeurMaxAffiche = y;
				}
			} else {
				if(debut) {
					deltaGraph++;
				}
			}
		}

		// Dessine le graphique
		DrawGraph();
	}

	/**
	 * Selection des points pour calcul de la frequence du signal.
	 * @param pEvent Le point s�lectionne sur la courbe
	 */
	public void pointSelect(ItemSelectEvent pEvent) {
		
		boolean pointTraite = false;
		frequence = Double.NEGATIVE_INFINITY;
		periode = Double.NEGATIVE_INFINITY;
		// Activation du premier point
		if (!pointMin.isActif()) {
			pointMin.setPoint(lignes.get(pEvent.getItemIndex() + deltaGraph));
			pointTraite = true;
		}
		// Activation du deuxieme point
		if (!pointMax.isActif() && !pointTraite) {
			pointMax.setPoint(lignes.get(pEvent.getItemIndex() + deltaGraph));
			pointTraite = true;
			// Si le point min est superieur au point max, on les echange
			if (pointMax.deltaOrdonnee(pointMin) < 0) {
				pointMin.swap(pointMax);
			}
			// Calcul de la frequence
			frequence = Math.round(100000000.0 / (pointMax.getOrdonnee() - pointMin.getOrdonnee())) / 100.0;
			periode = Math.round(100000.0 / frequence) / 100.0;
		}
		// Si les deux points etaient deja actifs
		// on retraite le premier point et on desactive le deuxieme
		if (!pointTraite) {
			pointMin.setPoint(lignes.get(pEvent.getItemIndex() + deltaGraph));
			pointMax.setAbscisse(0);
			pointMax.setOrdonnee(0);
			pointMax.setActif(false);
		}
	}

	/**
	 * (Re)initialisation du graph.
	 */
	private void InitGraph() {
		mesures.clear();
		mesures.setDatatipFormat(Graphique.FORMAT_DATATIP.toString());
		// Serie de points des environnements
		mesuresSerie = new ChartSeries();
		mesuresSerie.setLabel(Graphique.LABEL_SERIE.toString());
	}

	/**
	 * Ajoute l'habillage du graphique.
	 */
	private void DrawGraph() {
		mesures.addSeries(mesuresSerie);
		mesures.setTitle(Graphique.TITRE.toString());
		mesures.setLegendPosition(Graphique.LEGEND_POSITION.toString());

		Axis xAxis = mesures.getAxis(AxisType.X);
		xAxis.setLabel(Graphique.LABEL_ABSCISSES.toString());
		xAxis.setTickAngle(Integer.parseInt(Graphique.ANGLE_VALEUR_ORDONNEES.toString()));
		Axis yAxis = mesures.getAxis(AxisType.Y);
		yAxis.setLabel(Graphique.LABEL_ORDONNEES.toString());
	}

	/**
	 * Constructeur.
	 */
	public OscilloscopeBean() {
		// Initialisation de la langue
		locale = FRANCAIS;

		lignes = new ArrayList<>();
		mesures = new LineChartModel();

		// Initialise le graph
		InitGraph();

		// Serie vide
		mesuresSerie.set(0, 0);

		// Dessine le graphique
		DrawGraph();
		
		// Cree les points
		pointMin = new Point();
		pointMax = new Point();
	}
}
