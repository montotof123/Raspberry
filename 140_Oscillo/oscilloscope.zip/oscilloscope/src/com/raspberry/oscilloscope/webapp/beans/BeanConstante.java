package com.raspberry.oscilloscope.webapp.beans;

/**
 * Liste des constantes utile dans les bean.
 * 
 * @author ycse6373
 */
public final class BeanConstante {

	/**
	 * Constructeur prive.
	 */
	private BeanConstante() {
	}

	/**
	 * Liste des parametres graphiques.
	 */
	public enum Graphique {
		/**
		 * Label de la serie de mesure.
		 */
		LABEL_SERIE("mesures"),
		/**
		 * Titre.
		 */
		TITRE("Oscilloscope pour Raspberry"),
		/**
		 * Position de la legend du graph.
		 */
		LEGEND_POSITION("ne"),
		/**
		 * Angle des valeurs des ordonnees.
		 */
		ANGLE_VALEUR_ORDONNEES("-50"),
		/**
		 * Angle des valeurs des ordonnees.
		 */
		FORMAT_DATATIP("<span>Temps: %s</span><span> Valeur: %s</span>"),
		/**
		 * Label de l'abscisse.
		 */
		LABEL_ABSCISSES("Temps"),
		/**
		 * Label de l'ordonnee.
		 */
		LABEL_ORDONNEES("Valeurs");
		/**
		 * Le nom.
		 */
		private String name = "";

		/**
		 * Contructeur.
		 * 
		 * @param pName
		 *            Le nom
		 */
		Graphique(final String pName) {
			this.name = pName;
		}

		/**
		 * Conversion en String. return le nom
		 */
		@Override
		public String toString() {
			return name;
		}
	}
	
	public static final int ABSCISSE = 0;
	public static final int ORDONNEE = 1;
	
	public static final int NOMBRE_VALEUR_INITIALE = 2500;
	
	public static final String POINT_VIRGULE = ";";
	
	public static final String CHARSET_ISO_8859_P1 = "ISO-8859-1";
	
	public static final String ERREUR_LECTURE_FICHIER = "Erreur de lecture de fichier";
}
