package com.raspberry.oscilloscope.type;

import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.ABSCISSE;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.ORDONNEE;
import static com.raspberry.oscilloscope.webapp.beans.BeanConstante.POINT_VIRGULE;

/**
 * Point du graphique.
 * @author totof
 *
 */
public class Point{
	/**
	 * Abscisse.
	 */
	private double abscisse;
	
	/**
	 * Ordonnee
	 */
	private int ordonnee;
	
	/**
	 * Indique si le point a ete active.
	 */
	private boolean actif = false;

	/**
	 * (Re)initialisation d'un point.
	 * @param pPoint Le point au format xxx;yyy
	 */
	public void setPoint(String pPoint){
		String[] valeurs = pPoint.split(POINT_VIRGULE);
		ordonnee = Integer.parseInt(valeurs[ABSCISSE]);
		abscisse = Double.parseDouble(valeurs[ORDONNEE]);
		actif = true;
	}
	
	/**
	 * Getter de l'abscisse.
	 * 
	 * @return L'abscisse
	 */

	public double getAbscisse() {
		return abscisse;
	}

	/**
	 * Setter de l'abscisse.
	 * 
	 * @param pAbscisse l'abscisse
	 */
	public void setAbscisse(double pAbscisse) {
		this.abscisse = pAbscisse;
	}

	/**
	 * Getter de l'ordonnee.
	 * 
	 * @return L'ordonnee
	 */
	public int getOrdonnee() {
		return ordonnee;
	}
	
	/**
	 * Setter de l'ordonnee.
	 * 
	 * @param pOrdonnee l'ordonnee
	 */
	public void setOrdonnee(int pOrdonnee) {
		this.ordonnee = pOrdonnee;
	}

	/**
	 * Getter de l'activation.
	 * @return True si le point est actif
	 */
	public boolean isActif() {
		return actif;
	}

	/**
	 * Getter de l'activation.
	 * @param pActif Indique si le point est actif
	 */
	public void setActif(boolean pActif) {
		this.actif = pActif;
	}

	/**
	 * Swap de deux points
	 * 
	 * @param pPoint Le point � swapper
	 */
	public Point swap(Point pPoint){
		double abscisseTmp = pPoint.getAbscisse();
		int ordonneeTmp = pPoint.getOrdonnee();
		boolean arcifTmp = pPoint.isActif();
		
		pPoint.setAbscisse(abscisse);
		pPoint.setOrdonnee(ordonnee);
		pPoint.setActif(actif);
		
		abscisse = abscisseTmp;
		ordonnee = ordonneeTmp;
		actif = arcifTmp;
		
		return pPoint;
	}
	
	/**
	 * Donne la difference d'ordonnee entre deux points.
	 * @param pPoint Le point � comparer
	 * @return La difference d'ordonnee entre les deux points
	 */
	public int deltaOrdonnee(Point pPoint){
		return ordonnee - pPoint.getOrdonnee();
	}
}
