package com.raspberry.test.webapp.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.primefaces.event.ItemSelectEvent;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.ChartSeries;
import org.primefaces.model.chart.LineChartModel;

import com.raspberry.test.webapp.beans.BeanConstante.Graphique;

@ManagedBean(name = "testBean")
@SessionScoped
public class TestBean {
	// ****************
	// Constantes
	// ****************
	/**
	 * Francais.
	 */
	public static final String FRANCAIS = "fr";

	// ****************
	// Variable
	// ****************
	/**
	 * Langue.
	 */
	private String locale;

	/**
	 * Le nombre de mesures.
	 */
	private int nombreMesures = 1;

	/**
	 * La valeur min.
	 */
	private double valeurMin = Double.POSITIVE_INFINITY;

	/**
	 * La valeur max.
	 */
	private double valeurMax = Double.NEGATIVE_INFINITY;

	/**
	 * Le nombre de valeurs.
	 */
	private int nombreValeur;

	/**
	 * Graphique des mesures.
	 */
	private LineChartModel mesures;

	/**
	 * Serie de mesure.
	 */
	private ChartSeries mesuresSerie;

	/**
	 * Lignes du fichier de mesure.
	 */
	private List<String> lignes = null;

	/**
	 * Valeur minimal de l'abscisse.
	 */
	private int abscisseMin = Integer.MAX_VALUE;

	/**
	 * Valeur maximal de l'abscisse.
	 */
	private int abscisseMax = Integer.MIN_VALUE;

	// ****************
	// Getter et Setter
	// ****************
	/**
	 * Getter de la langue.
	 * 
	 * @return la langue
	 */
	public final String getLocale() {
		return locale;
	}

	/**
	 * Setter de la langue.
	 * 
	 * @param pLocale
	 *            la langue
	 */
	public final void setLocale(final String pLocale) {
		this.locale = pLocale;
	}

	/**
	 * Getter du nombre de mesures.
	 * 
	 * @return Le nombre de mesures
	 */
	public int getNombreMesures() {
		return nombreMesures;
	}

	/**
	 * Setter du nombre de mesures.
	 * 
	 * @param nombreMesures
	 *            Le nombre de mesures
	 */
	public void setNombreMesures(int nombreMesures) {
		this.nombreMesures = nombreMesures;
	}

	/**
	 * Getter de la valeur min.
	 * 
	 * @return La valeur min
	 */
	public double getValeurMin() {
		return valeurMin;
	}

	/**
	 * Setter de la valeur min.
	 * 
	 * @param valeurMin
	 *            La valeur min
	 */
	public void setValeurMin(double valeurMin) {
		this.valeurMin = valeurMin;
	}

	/**
	 * Getter de la valeur max.
	 * 
	 * @return La valeur max
	 */
	public double getValeurMax() {
		return valeurMax;
	}

	/**
	 * Setter de la valeur max.
	 * 
	 * @param valeurMax
	 *            La valeur max
	 */
	public void setValeurMax(double valeurMax) {
		this.valeurMax = valeurMax;
	}

	/**
	 * Getter du nombre de valeurs.
	 * 
	 * @return Le nombre de valeurs
	 */
	public int getNombreValeur() {
		return nombreValeur;
	}

	/**
	 * Setter du nombre de valeurs.
	 * 
	 * @param nombreValeur
	 *            Le nombre de valeurs
	 */
	public void setNombreValeur(int nombreValeur) {
		this.nombreValeur = nombreValeur;
	}

	/**
	 * Getter du graphe de mesures.
	 * 
	 * @return Le graphe de mesures
	 */
	public LineChartModel getMesures() {
		return mesures;
	}

	/**
	 * Setter du graphe de mesures.
	 * 
	 * @param mesures
	 *            Le graphe de mesures
	 */
	public void setMesures(LineChartModel mesures) {
		this.mesures = mesures;
	}

	/**
	 * Affiche un message d'erreur.
	 * 
	 * @param resume
	 *            Message resume
	 * @param detail
	 *            Message detail
	 */
	public void upError(String resume, String detail) {
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, resume, detail));
	}

	/**
	 * Lancement des mesures.
	 */
	public void launchMesure() {

		// Reinit valeurs
		lignes.clear();
		valeurMin = Double.POSITIVE_INFINITY;
		valeurMax = Double.NEGATIVE_INFINITY;
		abscisseMin = Integer.MAX_VALUE;
		abscisseMax = Integer.MIN_VALUE;
		
		// Calcul valeurs
		for (int compteur = 0; compteur < 50; compteur++) {
			String ligne = compteur + ";" + Math.random() * 5;
			lignes.add(ligne);
		}

		// Reinitialise le graph
		InitGraph();

		// Chargement des mesures
		nombreValeur = 0;
		for (String ligne : lignes) {
			String[] valeurs = ligne.split(";");
			int x = Integer.parseInt(valeurs[0]);
			double y = Double.parseDouble(valeurs[1]);
			mesuresSerie.set(x, y);
			// Calcul de la valeur min
			if (y < valeurMin) {
				valeurMin = y;
			}
			// Calcul de la valeur max
			if (y > valeurMax) {
				valeurMax = y;
			}
			// Calcul de l'abscisse min
			if (x < abscisseMin) {
				abscisseMin = x;
			}
			// Calcul de l'abscisse max
			if (x > abscisseMax) {
				abscisseMax = x;
			}

			nombreValeur++;
		}

		// Dessine le graphique
		DrawGraph();
	}

	public void pointSelect(ItemSelectEvent event) {
		System.out.println(event.getItemIndex());
		System.out.println(lignes.get(event.getItemIndex()));
	}

	/**
	 * (Re)initialisation du graph.
	 */
	private void InitGraph() {
		mesures.clear();
		// mesures.setDatatipFormat("<span>Valeur: %n %s</span>");
		mesures.setDatatipFormat(Graphique.FORMAT_DATATIP.toString());
		// Serie de points des environnements
		mesuresSerie = new ChartSeries();
		mesuresSerie.setLabel(Graphique.LABEL_SERIE.toString());
	}

	/**
	 * Ajoute l'habillage du graphique.
	 */
	private void DrawGraph() {
		mesures.addSeries(mesuresSerie);
		mesures.setTitle(Graphique.TITRE.toString());
		mesures.setLegendPosition(Graphique.LEGEND_POSITION.toString());

		Axis xAxis = mesures.getAxis(AxisType.X);
		xAxis.setLabel(Graphique.LABEL_ABSCISSES.toString());
		xAxis.setTickAngle(Integer.parseInt(Graphique.ANGLE_VALEUR_ORDONNEES.toString()));
		Axis yAxis = mesures.getAxis(AxisType.Y);
		yAxis.setLabel(Graphique.LABEL_ORDONNEES.toString());
	}

	/**
	 * Constructeur.
	 */
	public TestBean() {
		// Initialisation de la langue
		locale = FRANCAIS;

		lignes = new ArrayList<>();
		mesures = new LineChartModel();

		// Initialise le graph
		InitGraph();

		// Serie vide
		mesuresSerie.set(0, 0);

		// Dessine le graphique
		DrawGraph();
	}
}
